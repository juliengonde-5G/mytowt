"""
TOWT Planning - Database Initialization Script
Loads ports from CSV, creates fleet vessels, and creates default admin user.
Run inside the container: python -m scripts.init_db
"""
import asyncio
import csv
import sys
import os

# Add parent dir to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy import select, text
from app.database import engine, async_session, Base
from app.models import *
from app.auth import hash_password
from app.config import get_settings

settings = get_settings()


async def init_tables():
    """Create all tables."""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    print("✅ Tables created.")


async def load_ports():
    """Load ports from CSV file."""
    async with async_session() as session:
        # Check if ports already loaded
        result = await session.execute(select(Port).limit(1))
        if result.scalar_one_or_none():
            print("ℹ️  Ports already loaded, skipping.")
            return

        csv_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "ports.csv")
        if not os.path.exists(csv_path):
            print(f"❌ Port file not found: {csv_path}")
            return

        shortcut_locodes = {"FRFEC", "BRSSO"}
        count = 0

        with open(csv_path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f, delimiter=";")
            batch = []
            for row in reader:
                locode = row.get("code", "").strip()
                if not locode:
                    continue
                port = Port(
                    locode=locode,
                    name=row.get("name", "").strip(),
                    latitude=float(row["latitude"]) if row.get("latitude") else None,
                    longitude=float(row["longitude"]) if row.get("longitude") else None,
                    country_code=row.get("country_code", "").strip(),
                    zone_code=row.get("zone_code", "").strip(),
                    is_shortcut=locode in shortcut_locodes,
                )
                batch.append(port)
                count += 1

                if len(batch) >= 500:
                    session.add_all(batch)
                    await session.flush()
                    batch = []

            if batch:
                session.add_all(batch)

        await session.commit()
        print(f"✅ {count} ports loaded.")


async def create_vessels():
    """Create the 4 TOWT vessels."""
    async with async_session() as session:
        result = await session.execute(select(Vessel).limit(1))
        if result.scalar_one_or_none():
            print("ℹ️  Vessels already exist, skipping.")
            return

        vessels = [
            Vessel(code=1, name="Anemos", default_speed=10.0, default_elongation=1.15, capacity_palettes=82),
            Vessel(code=2, name="Artemis", default_speed=10.0, default_elongation=1.15, capacity_palettes=82),
            Vessel(code=3, name="Atlantis", default_speed=10.0, default_elongation=1.15, capacity_palettes=82),
            Vessel(code=4, name="Atlas", default_speed=10.0, default_elongation=1.15, capacity_palettes=82),
        ]
        session.add_all(vessels)
        await session.commit()
        print("✅ 4 vessels created (Anemos, Artemis, Atlantis, Atlas).")


async def create_admin():
    """Create default admin user."""
    async with async_session() as session:
        result = await session.execute(select(User).where(User.username == "admin"))
        if result.scalar_one_or_none():
            print("ℹ️  Admin user already exists, skipping.")
            return

        admin = User(
            username="admin",
            email="admin@towt.eu",
            hashed_password=hash_password("towt2025"),
            full_name="Administrateur TOWT",
            role="admin",
            is_active=True,
        )
        session.add(admin)
        await session.commit()
        print("✅ Admin user created (username: admin, password: towt2025).")


async def create_default_emission_params():
    """Create default emission calculation parameters."""
    async with async_session() as session:
        result = await session.execute(select(EmissionParameter).limit(1))
        if result.scalar_one_or_none():
            print("ℹ️  Emission parameters already exist, skipping.")
            return

        params = [
            EmissionParameter(
                parameter_name="conventional_emission_factor",
                parameter_value=15.0,
                unit="gCO2/t.km",
                description="Facteur d'émission cargo conventionnel"
            ),
            EmissionParameter(
                parameter_name="sail_emission_factor",
                parameter_value=2.0,
                unit="gCO2/t.km",
                description="Facteur d'émission voilier cargo TOWT"
            ),
            EmissionParameter(
                parameter_name="reduction_rate",
                parameter_value=87.0,
                unit="%",
                description="Taux de réduction des émissions vs conventionnel"
            ),
        ]
        session.add_all(params)
        await session.commit()
        print("✅ Default emission parameters created.")


async def create_default_opex_params():
    """Create default OPEX parameters."""
    async with async_session() as session:
        result = await session.execute(select(OpexParameter).limit(1))
        if result.scalar_one_or_none():
            print("ℹ️  OPEX parameters already exist, skipping.")
            return

        params = [
            OpexParameter(parameter_name="fuel_cost_per_day", parameter_value=500, unit="EUR/jour", category="fuel", description="Coût carburant journalier en mer"),
            OpexParameter(parameter_name="crew_cost_per_day", parameter_value=2000, unit="EUR/jour", category="crew", description="Coût équipage journalier"),
            OpexParameter(parameter_name="maintenance_per_day", parameter_value=300, unit="EUR/jour", category="maintenance", description="Coût maintenance journalier"),
            OpexParameter(parameter_name="insurance_per_day", parameter_value=400, unit="EUR/jour", category="insurance", description="Coût assurance journalier"),
            OpexParameter(parameter_name="provisions_per_day", parameter_value=150, unit="EUR/jour", category="provisions", description="Coût avitaillement journalier"),
        ]
        session.add_all(params)
        await session.commit()
        print("✅ Default OPEX parameters created.")


async def main():
    print("=" * 50)
    print("🚢 TOWT Planning - Database Initialization")
    print("=" * 50)
    await init_tables()
    await load_ports()
    await create_vessels()
    await create_admin()
    await create_default_emission_params()
    await create_default_opex_params()
    print("=" * 50)
    print("🎉 Initialization complete!")
    print("=" * 50)


if __name__ == "__main__":
    asyncio.run(main())
