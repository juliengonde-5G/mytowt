from fastapi import APIRouter, Request, Depends, Form, HTTPException, Query
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
from app.templating import templates
from sqlalchemy.ext.asyncio import AsyncSession
from app.utils.activity import log_activity, get_client_ip
from sqlalchemy import select, func
from sqlalchemy.orm import selectinload
from typing import Optional
from datetime import datetime
import csv
import io

from app.database import get_db
from app.auth import get_current_user
from app.models.user import User
from app.models.vessel import Vessel
from app.models.port import Port
from app.models.leg import Leg
from app.models.finance import OpexParameter, PortConfig
from app.models.emission_parameter import EmissionParameter

router = APIRouter(prefix="/admin", tags=["admin"])

USER_ROLES = [
    {"value": "administrateur", "label": "Administrateur"},
    {"value": "operation", "label": "Opération"},
    {"value": "armement", "label": "Armement"},
    {"value": "technique", "label": "Technique"},
    {"value": "data_analyst", "label": "Data Analyst"},
    {"value": "marins", "label": "Marins"},
]




def pf(val, default=0):
    if val is None or (isinstance(val, str) and val.strip() == ""):
        return default
    try:
        if isinstance(val, str):
            val = val.replace(" ", "").replace("\u00a0", "")
            if "." in val and "," in val:
                val = val.replace(".", "").replace(",", ".")
            elif "," in val:
                val = val.replace(",", ".")
        return float(val)
    except (ValueError, TypeError):
        return default


# ─── SETTINGS HOME ───────────────────────────────────────────
@router.get("/settings", response_class=HTMLResponse)
async def settings_home(
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    # Users
    users_result = await db.execute(select(User).order_by(User.id))
    users = users_result.scalars().all()

    # Vessels
    vessels_result = await db.execute(select(Vessel).order_by(Vessel.code))
    vessels = vessels_result.scalars().all()

    # Port configs
    ports_result = await db.execute(
        select(PortConfig).options(selectinload(PortConfig.port)).order_by(PortConfig.port_locode)
    )
    port_configs = ports_result.scalars().all()

    # OPEX
    opex_result = await db.execute(select(OpexParameter).order_by(OpexParameter.parameter_name))
    opex_params = opex_result.scalars().all()

    # Emission params
    emission_result = await db.execute(select(EmissionParameter).order_by(EmissionParameter.parameter_name))
    emission_params = emission_result.scalars().all()

    # Locked legs count
    locked_result = await db.execute(
        select(func.count(Leg.id)).where(Leg.status == "completed")
    )
    locked_count = locked_result.scalar() or 0

    # Cabin pricing grid
    from app.models.passenger import CabinPriceGrid, CABIN_TYPE_LABELS
    pricing_result = await db.execute(
        select(CabinPriceGrid).order_by(CabinPriceGrid.origin_locode, CabinPriceGrid.destination_locode, CabinPriceGrid.cabin_type)
    )
    pricing_grid = pricing_result.scalars().all()

    # Existing routes (unique origin→dest pairs from legs)
    from sqlalchemy.orm import selectinload as sl
    routes_result = await db.execute(
        select(
            Leg.departure_port_locode, Leg.arrival_port_locode
        ).distinct()
    )
    route_pairs = routes_result.all()

    # Collect unique port locodes used in routes
    route_locodes = set()
    for dep, arr in route_pairs:
        route_locodes.add(dep)
        route_locodes.add(arr)

    # Load port names for those locodes
    route_ports = {}
    if route_locodes:
        ports_result = await db.execute(
            select(Port).where(Port.locode.in_(route_locodes)).order_by(Port.name)
        )
        for p in ports_result.scalars().all():
            route_ports[p.locode] = p.name

    # Build structured routes list for template
    existing_routes = sorted(
        [{"dep": dep, "arr": arr, "dep_name": route_ports.get(dep, dep), "arr_name": route_ports.get(arr, arr)}
         for dep, arr in route_pairs],
        key=lambda r: (r["dep_name"], r["arr_name"])
    )

    # Insurance contracts
    from app.models.finance import InsuranceContract
    ins_result = await db.execute(select(InsuranceContract).order_by(InsuranceContract.guarantee_type))
    insurance_contracts = ins_result.scalars().all()

    return templates.TemplateResponse("admin/settings.html", {
        "request": request, "user": user,
        "users": users, "vessels": vessels,
        "port_configs": port_configs,
        "opex_params": opex_params,
        "emission_params": emission_params,
        "locked_count": locked_count,
        "pricing_grid": pricing_grid,
        "existing_routes": existing_routes,
        "route_ports": route_ports,
        "cabin_type_labels": CABIN_TYPE_LABELS,
        "insurance_contracts": insurance_contracts,
        "active_module": "settings",
    })


# ─── USERS CRUD ──────────────────────────────────────────────
@router.get("/users", response_class=HTMLResponse)
async def users_list(
    request: Request, user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(User).order_by(User.id))
    users = result.scalars().all()
    return templates.TemplateResponse("admin/users.html", {
        "request": request, "user": user, "users": users,
        "active_module": "settings",
    })


@router.get("/users/create", response_class=HTMLResponse)
async def user_create_form(request: Request, user: User = Depends(get_current_user)):
    return templates.TemplateResponse("admin/user_form.html", {
        "request": request, "user": user, "edit_user": None, "error": None, "roles": USER_ROLES,
    })


@router.post("/users/create", response_class=HTMLResponse)
async def user_create_submit(
    request: Request,
    username: str = Form(...), password: str = Form(...),
    full_name: str = Form(""), role: str = Form("operation"),
    email: str = Form(""),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    from app.auth import hash_password
    if not email:
        email = f"{username}@towt.eu"
    existing = await db.execute(select(User).where(User.username == username))
    if existing.scalar_one_or_none():
        return templates.TemplateResponse("admin/user_form.html", {
            "request": request, "user": user, "edit_user": None,
            "error": "Ce nom d'utilisateur existe déjà.", "roles": USER_ROLES,
        })
    pwd_hash = hash_password(password)
    new_user = User(username=username, email=email, hashed_password=pwd_hash, full_name=full_name, role=role)
    db.add(new_user)
    await log_activity(db, user=user, action="create", module="admin",
                       entity_type="user", entity_id=new_user.id,
                       entity_label=new_user.full_name, detail=f"role: {new_user.role}",
                       ip_address=get_client_ip(request))
    await db.flush()
    return RedirectResponse(url="/admin/users", status_code=303)


@router.get("/users/{uid}/edit", response_class=HTMLResponse)
async def user_edit_form(
    uid: int, request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(User).where(User.id == uid))
    edit_user = result.scalar_one_or_none()
    if not edit_user:
        raise HTTPException(status_code=404)
    return templates.TemplateResponse("admin/user_form.html", {
        "request": request, "user": user, "edit_user": edit_user, "error": None, "roles": USER_ROLES,
    })


@router.post("/users/{uid}/edit", response_class=HTMLResponse)
async def user_edit_submit(
    uid: int, request: Request,
    full_name: str = Form(""), role: str = Form("viewer"),
    password: Optional[str] = Form(None),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    from app.auth import hash_password as _hp
    result = await db.execute(select(User).where(User.id == uid))
    edit_user = result.scalar_one_or_none()
    if not edit_user:
        raise HTTPException(status_code=404)
    edit_user.full_name = full_name
    edit_user.role = role
    if password and password.strip():
        edit_user.hashed_password = _hp(password)
    await db.flush()
    return RedirectResponse(url="/admin/users", status_code=303)


@router.delete("/users/{uid}", response_class=HTMLResponse)
async def user_delete(
    uid: int, request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(User).where(User.id == uid))
    u = result.scalar_one_or_none()
    if u and u.id != user.id:
        await log_activity(db, user=user, action="delete", module="admin",
                           entity_type="user", entity_id=uid, entity_label=u.full_name,
                           ip_address=get_client_ip(request))
        await db.delete(u)
        await db.flush()
    if request.headers.get("HX-Request"):
        return HTMLResponse(content="", headers={"HX-Redirect": "/admin/users"})
    return RedirectResponse(url="/admin/users", status_code=303)


# ─── VESSELS ─────────────────────────────────────────────────
@router.get("/vessels/{vid}/edit", response_class=HTMLResponse)
async def vessel_edit_form(
    vid: int, request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Vessel).where(Vessel.id == vid))
    vessel = result.scalar_one_or_none()
    if not vessel:
        raise HTTPException(status_code=404)
    return templates.TemplateResponse("admin/vessel_form.html", {
        "request": request, "user": user, "vessel": vessel,
    })


@router.post("/vessels/{vid}/edit", response_class=HTMLResponse)
async def vessel_edit_submit(
    vid: int, request: Request,
    name: str = Form(...),
    capacity_palettes: str = Form("0"),
    default_speed: str = Form("8"),
    default_elongation: str = Form("1.25"),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Vessel).where(Vessel.id == vid))
    vessel = result.scalar_one_or_none()
    if not vessel:
        raise HTTPException(status_code=404)
    vessel.name = name
    vessel.capacity_palettes = int(pf(capacity_palettes, 0))
    vessel.default_speed = pf(default_speed, 8)
    vessel.default_elongation = pf(default_elongation, 1.25)
    await db.flush()
    if request.headers.get("HX-Request"):
        return HTMLResponse(content="", headers={"HX-Redirect": "/admin/settings"})
    return RedirectResponse(url="/admin/settings", status_code=303)


# ─── OPEX PARAMETER ──────────────────────────────────────────
@router.post("/opex/update", response_class=HTMLResponse)
async def opex_update(
    request: Request,
    opex_daily_rate: str = Form("11600"),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(OpexParameter).where(OpexParameter.parameter_name == "opex_daily_rate")
    )
    param = result.scalar_one_or_none()
    if param:
        param.parameter_value = pf(opex_daily_rate, 11600)
    else:
        param = OpexParameter(
            parameter_name="opex_daily_rate", parameter_value=pf(opex_daily_rate, 11600),
            unit="EUR/jour", category="global", description="Coût journalier en mer",
        )
        db.add(param)
    await db.flush()
    if request.headers.get("HX-Request"):
        return HTMLResponse(content="", headers={"HX-Redirect": "/admin/settings"})
    return RedirectResponse(url="/admin/settings", status_code=303)


# ─── LOCK/UNLOCK LEGS ────────────────────────────────────────
@router.post("/legs/lock", response_class=HTMLResponse)
async def lock_completed_legs(
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Lock all legs where ATD is set (voyage completed)."""
    result = await db.execute(select(Leg).where(Leg.atd != None, Leg.status != "completed"))
    legs = result.scalars().all()
    count = 0
    for leg in legs:
        leg.status = "completed"
        count += 1
    await db.flush()
    if request.headers.get("HX-Request"):
        return HTMLResponse(content="", headers={"HX-Redirect": f"/admin/settings?locked={count}"})
    return RedirectResponse(url="/admin/settings", status_code=303)


@router.post("/legs/{lid}/unlock", response_class=HTMLResponse)
async def unlock_leg(
    lid: int, request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Leg).where(Leg.id == lid))
    leg = result.scalar_one_or_none()
    if leg:
        leg.status = "planned"
        await db.flush()
    if request.headers.get("HX-Request"):
        return HTMLResponse(content="", headers={"HX-Redirect": "/admin/settings"})
    return RedirectResponse(url="/admin/settings", status_code=303)


# ─── DATABASE MANAGEMENT ─────────────────────────────────────

# Helper: export a table to CSV
def _table_to_csv(rows, columns):
    output = io.StringIO()
    writer = csv.writer(output, delimiter=";")
    writer.writerow(columns)
    for row in rows:
        writer.writerow([getattr(row, c, '') for c in columns])
    return output.getvalue()

def _date_fmt(val):
    if val is None: return ''
    try: return val.strftime('%d/%m/%Y %H:%M')
    except: return str(val)

# Table definitions for export/purge
TABLE_DEFS = {
    "legs": {"label": "Legs", "tables": ["legs"]},
    "orders": {"label": "Commandes", "tables": ["orders", "order_assignments"]},
    "passengers": {"label": "Passagers", "tables": ["passenger_bookings", "passengers", "passenger_payments", "passenger_documents", "preboarding_forms", "passenger_audit_logs"]},
    "cargo": {"label": "Cargo", "tables": ["packing_lists", "packing_list_batches", "packing_list_audit"]},
    "finance": {"label": "Finance", "tables": ["leg_finances"]},
    "claims": {"label": "Claims", "tables": ["claims", "claim_documents", "claim_timeline"]},
    "crew": {"label": "Équipage", "tables": ["crew_members", "crew_assignments"]},
    "crew_assignments": {"label": "Affectations", "tables": ["crew_assignments"]},
    "sof": {"label": "SOF", "tables": ["sof_events"]},
    "messages": {"label": "Messages", "tables": ["portal_messages"]},
    "notifications": {"label": "Notifications", "tables": ["notifications"]},
    "config": {"label": "Config", "tables": ["vessels", "ports", "port_configs", "opex_parameters", "emission_parameters", "cabin_price_grid", "insurance_contracts"]},
}


@router.get("/export/global")
async def export_global(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    import zipfile
    from sqlalchemy import text
    zip_buffer = io.BytesIO()
    now_str = datetime.now().strftime("%Y%m%d_%H%M")

    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zf:
        # Get all table names from the database
        result = await db.execute(text(
            "SELECT tablename FROM pg_tables WHERE schemaname = 'public' ORDER BY tablename"
        ))
        tables = [r[0] for r in result.fetchall()]

        for table_name in tables:
            try:
                cols_result = await db.execute(text(
                    f"SELECT column_name FROM information_schema.columns WHERE table_name = '{table_name}' ORDER BY ordinal_position"
                ))
                columns = [r[0] for r in cols_result.fetchall()]
                rows_result = await db.execute(text(f'SELECT * FROM "{table_name}" LIMIT 50000'))
                rows = rows_result.fetchall()

                output = io.StringIO()
                writer = csv.writer(output, delimiter=";")
                writer.writerow(columns)
                for row in rows:
                    writer.writerow([_date_fmt(v) if hasattr(v, 'strftime') else ('' if v is None else str(v)) for v in row])

                zf.writestr(f"{table_name}.csv", output.getvalue())
            except Exception:
                continue

    zip_buffer.seek(0)
    return StreamingResponse(
        iter([zip_buffer.getvalue()]),
        media_type="application/zip",
        headers={"Content-Disposition": f"attachment; filename=towt_export_complet_{now_str}.zip"},
    )


@router.get("/export/selective")
async def export_selective(
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    import zipfile
    from sqlalchemy import text
    tables_param = request.query_params.getlist("tables")
    if not tables_param:
        return RedirectResponse(url="/admin/settings#database", status_code=303)

    zip_buffer = io.BytesIO()
    now_str = datetime.now().strftime("%Y%m%d_%H%M")
    selected_tables = set()
    for key in tables_param:
        if key in TABLE_DEFS:
            selected_tables.update(TABLE_DEFS[key]["tables"])

    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zf:
        for table_name in sorted(selected_tables):
            try:
                cols_result = await db.execute(text(
                    f"SELECT column_name FROM information_schema.columns WHERE table_name = '{table_name}' ORDER BY ordinal_position"
                ))
                columns = [r[0] for r in cols_result.fetchall()]
                if not columns:
                    continue
                rows_result = await db.execute(text(f'SELECT * FROM "{table_name}" LIMIT 50000'))
                rows = rows_result.fetchall()

                output = io.StringIO()
                writer = csv.writer(output, delimiter=";")
                writer.writerow(columns)
                for row in rows:
                    writer.writerow([_date_fmt(v) if hasattr(v, 'strftime') else ('' if v is None else str(v)) for v in row])

                zf.writestr(f"{table_name}.csv", output.getvalue())
            except Exception:
                continue

    zip_buffer.seek(0)
    return StreamingResponse(
        iter([zip_buffer.getvalue()]),
        media_type="application/zip",
        headers={"Content-Disposition": f"attachment; filename=towt_export_selection_{now_str}.zip"},
    )


@router.get("/export/files")
async def export_files(
    user: User = Depends(get_current_user),
):
    import zipfile, os
    zip_buffer = io.BytesIO()
    now_str = datetime.now().strftime("%Y%m%d_%H%M")

    upload_dirs = [
        ("/app/uploads/passenger_docs", "passenger_docs"),
        ("/app/data/claims", "claims"),
        ("app/static/uploads/orders", "orders"),
    ]

    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zf:
        for dir_path, prefix in upload_dirs:
            if os.path.exists(dir_path):
                for root, dirs, files in os.walk(dir_path):
                    for fname in files:
                        full_path = os.path.join(root, fname)
                        arc_name = os.path.join(prefix, os.path.relpath(full_path, dir_path))
                        try:
                            zf.write(full_path, arc_name)
                        except Exception:
                            continue

    zip_buffer.seek(0)
    return StreamingResponse(
        iter([zip_buffer.getvalue()]),
        media_type="application/zip",
        headers={"Content-Disposition": f"attachment; filename=towt_fichiers_{now_str}.zip"},
    )


@router.post("/database/purge-selective", response_class=HTMLResponse)
async def purge_selective(
    request: Request,
    confirm_text: str = Form(""),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if confirm_text.strip() != "SUPPRIMER":
        return RedirectResponse(url="/admin/settings#database", status_code=303)
    form = await request.form()
    tables_param = form.getlist("tables")
    if not tables_param:
        return RedirectResponse(url="/admin/settings#database", status_code=303)

    from sqlalchemy import text

    # Order matters for FK constraints — delete children first
    purge_order = [
        "notifications", "messages", "sof", "claims",
        "cargo", "passengers", "finance", "crew_assignments", "orders", "legs",
    ]

    table_sql = {
        "notifications": ["DELETE FROM notifications"],
        "messages": ["DELETE FROM portal_messages"],
        "sof": ["DELETE FROM sof_events WHERE event_type NOT IN ('CLAIM_DECLARED','CLAIM_UPDATED')"],
        "claims": ["DELETE FROM claim_timeline", "DELETE FROM claim_documents", "DELETE FROM claims"],
        "cargo": ["DELETE FROM packing_list_audit", "DELETE FROM packing_list_batches", "DELETE FROM packing_lists"],
        "passengers": [
            "DELETE FROM passenger_audit_logs", "DELETE FROM preboarding_forms",
            "DELETE FROM passenger_documents", "DELETE FROM passenger_payments",
            "DELETE FROM passengers", "DELETE FROM passenger_bookings",
        ],
        "orders": ["DELETE FROM order_assignments", "DELETE FROM orders"],
        "finance": ["DELETE FROM leg_finances"],
        "crew_assignments": ["DELETE FROM crew_assignments"],
        "legs": [
            "DELETE FROM sof_events", "DELETE FROM escale_operations",
            "DELETE FROM onboard_notifications", "DELETE FROM cargo_documents",
            "DELETE FROM docker_shifts", "DELETE FROM leg_finances", "DELETE FROM leg_kpis",
            "DELETE FROM legs",
        ],
    }

    for key in purge_order:
        if key in tables_param and key in table_sql:
            for sql in table_sql[key]:
                try:
                    await db.execute(text(sql))
                except Exception:
                    pass
    await db.commit()
    return RedirectResponse(url="/admin/settings#database", status_code=303)


@router.post("/database/reset", response_class=HTMLResponse)
async def reset_database(
    request: Request,
    confirm_text: str = Form(""),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    form = await request.form()
    if confirm_text.strip() != "REINITIALISER" or not form.get("confirm_checkbox"):
        return RedirectResponse(url="/admin/settings#database", status_code=303)

    from sqlalchemy import text

    # Delete everything in dependency order, keep users + config
    purge_sql = [
        "DELETE FROM notifications",
        "DELETE FROM portal_messages",
        "DELETE FROM claim_timeline",
        "DELETE FROM claim_documents",
        "DELETE FROM claims",
        "DELETE FROM packing_list_audit",
        "DELETE FROM packing_list_batches",
        "DELETE FROM packing_lists",
        "DELETE FROM passenger_audit_logs",
        "DELETE FROM preboarding_forms",
        "DELETE FROM passenger_documents",
        "DELETE FROM passenger_payments",
        "DELETE FROM passengers",
        "DELETE FROM passenger_bookings",
        "DELETE FROM order_assignments",
        "DELETE FROM orders",
        "DELETE FROM crew_assignments",
        "DELETE FROM sof_events",
        "DELETE FROM onboard_notifications",
        "DELETE FROM cargo_documents",
        "DELETE FROM docker_shifts",
        "DELETE FROM escale_operations",
        "DELETE FROM leg_finances",
        "DELETE FROM leg_kpis",
        "DELETE FROM legs",
    ]
    for sql in purge_sql:
        try:
            await db.execute(text(sql))
        except Exception:
            pass
    await db.commit()
    return RedirectResponse(url="/admin/settings#database", status_code=303)


@router.get("/database/stats", response_class=HTMLResponse)
async def database_stats(
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    from sqlalchemy import text
    result = await db.execute(text(
        "SELECT tablename FROM pg_tables WHERE schemaname = 'public' ORDER BY tablename"
    ))
    tables = [r[0] for r in result.fetchall()]
    stats = []
    for t in tables:
        try:
            cnt = await db.execute(text(f'SELECT COUNT(*) FROM "{t}"'))
            count = cnt.scalar() or 0
            stats.append((t, count))
        except Exception:
            stats.append((t, "?"))

    html = '<div class="db-stat-grid">'
    for name, count in stats:
        html += f'<div class="db-stat-item"><span>{name}</span><strong>{count}</strong></div>'
    html += '</div>'
    return HTMLResponse(html)


@router.post("/database/cleanup-notifications", response_class=HTMLResponse)
async def cleanup_notifications(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    from sqlalchemy import text
    await db.execute(text(
        "DELETE FROM notifications WHERE is_archived = TRUE AND created_at < NOW() - INTERVAL '30 days'"
    ))
    await db.commit()
    return RedirectResponse(url="/admin/settings#database", status_code=303)


@router.post("/database/cleanup-audit", response_class=HTMLResponse)
async def cleanup_audit(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    from sqlalchemy import text
    await db.execute(text(
        "DELETE FROM packing_list_audit WHERE created_at < NOW() - INTERVAL '12 months'"
    ))
    await db.execute(text(
        "DELETE FROM passenger_audit_logs WHERE created_at < NOW() - INTERVAL '12 months'"
    ))
    await db.commit()
    return RedirectResponse(url="/admin/settings#database", status_code=303)


# ─── USER LANGUAGE ────────────────────────────────────────────
@router.post("/settings/language", response_class=HTMLResponse)
async def update_language(
    request: Request,
    language: str = Form(...),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    from app.i18n import SUPPORTED_LANGUAGES
    if language in SUPPORTED_LANGUAGES:
        user.language = language
        await db.flush()
    url = "/admin/settings"
    response = RedirectResponse(url=url, status_code=303)
    response.set_cookie("towt_lang", language, max_age=365*24*3600)
    return response


# ─── CABIN PRICING GRID ──────────────────────────────────────
@router.post("/settings/pricing/add", response_class=HTMLResponse)
async def pricing_add(
    request: Request,
    origin_locode: str = Form(...),
    destination_locode: str = Form(...),
    cabin_type: str = Form(...),
    price: float = Form(...),
    deposit_pct: int = Form(30),
    notes: str = Form(""),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    from app.models.passenger import CabinPriceGrid
    entry = CabinPriceGrid(
        origin_locode=origin_locode.strip().upper(),
        destination_locode=destination_locode.strip().upper(),
        cabin_type=cabin_type,
        price=price,
        deposit_pct=deposit_pct,
        notes=notes.strip() or None,
    )
    db.add(entry)
    await db.flush()
    return RedirectResponse(url="/admin/settings#pricing", status_code=303)


@router.post("/settings/pricing/{price_id}/edit", response_class=HTMLResponse)
async def pricing_edit(
    price_id: int, request: Request,
    price: float = Form(...),
    deposit_pct: int = Form(30),
    notes: str = Form(""),
    is_active: Optional[str] = Form(None),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    from app.models.passenger import CabinPriceGrid
    entry = await db.get(CabinPriceGrid, price_id)
    if entry:
        entry.price = price
        entry.deposit_pct = deposit_pct
        entry.notes = notes.strip() or None
        entry.is_active = is_active == "on"
        await db.flush()
    return RedirectResponse(url="/admin/settings#pricing", status_code=303)


@router.delete("/settings/pricing/{price_id}", response_class=HTMLResponse)
async def pricing_delete(
    price_id: int, request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    from app.models.passenger import CabinPriceGrid
    entry = await db.get(CabinPriceGrid, price_id)
    if entry:
        await db.delete(entry)
        await db.flush()
    return HTMLResponse("", status_code=200)


# ─── INSURANCE CONTRACTS ─────────────────────────────────────
@router.post("/settings/insurance/add", response_class=HTMLResponse)
async def insurance_add(
    request: Request,
    guarantee_type: str = Form(...),
    insurer_name: str = Form(...),
    insurer_email: str = Form(""),
    insurer_phone: str = Form(""),
    insurer_address: str = Form(""),
    broker_reference: str = Form(""),
    franchise_amount: str = Form("0"),
    guarantee_ceiling: str = Form("0"),
    policy_number: str = Form(""),
    notes: str = Form(""),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    from app.models.finance import InsuranceContract
    entry = InsuranceContract(
        guarantee_type=guarantee_type,
        insurer_name=insurer_name,
        insurer_email=insurer_email or None,
        insurer_phone=insurer_phone or None,
        insurer_address=insurer_address or None,
        broker_reference=broker_reference or None,
        franchise_amount=pf(franchise_amount, 0),
        guarantee_ceiling=pf(guarantee_ceiling, 0),
        policy_number=policy_number or None,
        notes=notes or None,
    )
    db.add(entry)
    await db.flush()
    return RedirectResponse(url="/admin/settings#insurance", status_code=303)


@router.post("/settings/insurance/{ins_id}/edit", response_class=HTMLResponse)
async def insurance_edit(
    ins_id: int, request: Request,
    insurer_name: str = Form(...),
    insurer_email: str = Form(""),
    insurer_phone: str = Form(""),
    insurer_address: str = Form(""),
    broker_reference: str = Form(""),
    franchise_amount: str = Form("0"),
    guarantee_ceiling: str = Form("0"),
    policy_number: str = Form(""),
    is_active: Optional[str] = Form(None),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    from app.models.finance import InsuranceContract
    entry = await db.get(InsuranceContract, ins_id)
    if entry:
        entry.insurer_name = insurer_name
        entry.insurer_email = insurer_email or None
        entry.insurer_phone = insurer_phone or None
        entry.insurer_address = insurer_address or None
        entry.broker_reference = broker_reference or None
        entry.franchise_amount = pf(franchise_amount, 0)
        entry.guarantee_ceiling = pf(guarantee_ceiling, 0)
        entry.policy_number = policy_number or None
        entry.is_active = is_active == "on"
        await db.flush()
    return RedirectResponse(url="/admin/settings#insurance", status_code=303)


# ─── MON COMPTE (accessible à tous les rôles) ─────────────────
@router.get("/my-account", response_class=HTMLResponse)
async def my_account(
    request: Request,
    success: Optional[str] = Query(None),
    error: Optional[str] = Query(None),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    from app.i18n import SUPPORTED_LANGUAGES
    return templates.TemplateResponse("admin/my_account.html", {
        "request": request,
        "user": user,
        "languages": SUPPORTED_LANGUAGES,
        "active_module": "my-account",
        "success": success,
        "error": error,
    })


@router.post("/my-account/password", response_class=HTMLResponse)
async def my_account_password(
    request: Request,
    current_password: str = Form(...),
    new_password: str = Form(...),
    confirm_password: str = Form(...),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    from app.auth import verify_password, hash_password
    if not verify_password(current_password, user.hashed_password):
        return RedirectResponse(url="/admin/my-account?error=Mot+de+passe+actuel+incorrect", status_code=303)
    if new_password != confirm_password:
        return RedirectResponse(url="/admin/my-account?error=Les+mots+de+passe+ne+correspondent+pas", status_code=303)
    if len(new_password) < 4:
        return RedirectResponse(url="/admin/my-account?error=Le+mot+de+passe+doit+faire+au+moins+4+caractères", status_code=303)
    user.hashed_password = hash_password(new_password)
    await db.flush()
    return RedirectResponse(url="/admin/my-account?success=Mot+de+passe+modifié+avec+succès", status_code=303)


@router.post("/my-account/language", response_class=HTMLResponse)
async def my_account_language(
    request: Request,
    language: str = Form(...),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    from app.i18n import SUPPORTED_LANGUAGES
    if language in SUPPORTED_LANGUAGES:
        user.language = language
        await db.flush()
    return RedirectResponse(url="/admin/my-account?success=Langue+modifiée+avec+succès", status_code=303)


# ─── ACTIVITY LOGS ──────────────────────────────────────────
@router.get("/activity-logs", response_class=HTMLResponse)
async def activity_logs(
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    page: int = Query(1, ge=1),
    action: Optional[str] = Query(None),
    module: Optional[str] = Query(None),
    user_id: Optional[int] = Query(None),
):
    from app.models.activity_log import ActivityLog
    from sqlalchemy import desc

    per_page = 50
    q = select(ActivityLog)

    if action:
        q = q.where(ActivityLog.action == action)
    if module:
        q = q.where(ActivityLog.module == module)
    if user_id:
        q = q.where(ActivityLog.user_id == user_id)

    # Count
    count_q = select(func.count()).select_from(q.subquery())
    total = (await db.execute(count_q)).scalar() or 0
    total_pages = max(1, (total + per_page - 1) // per_page)

    # Fetch page
    q = q.order_by(desc(ActivityLog.created_at)).offset((page - 1) * per_page).limit(per_page)
    result = await db.execute(q)
    logs = result.scalars().all()

    # Action labels
    action_labels = {
        "login": "🔑 Connexion",
        "logout": "🚪 Déconnexion",
        "login_fail": "🚫 Échec",
        "create": "➕ Création",
        "update": "✏️ Modification",
        "delete": "🗑️ Suppression",
    }

    # Build HTML
    rows = []
    for log in logs:
        ts = log.created_at.strftime("%d/%m/%Y %H:%M") if log.created_at else ""
        a_label = action_labels.get(log.action, log.action)
        a_cls = f"al-{log.action}"

        entity = ""
        if log.entity_type:
            entity = f'<span style="font-size:11px;color:#888;">{log.entity_type}</span>'
            if log.entity_label:
                entity += f' <strong style="font-size:12px;">{log.entity_label}</strong>'

        detail_html = ""
        if log.detail:
            detail_html = f'<div style="font-size:10px;color:#888;margin-top:2px;">{log.detail}</div>'

        rows.append(f'''<tr>
            <td class="al-time">{ts}</td>
            <td>{log.user_name or '<span style="color:#ccc;">—</span>'}</td>
            <td><span class="al-action {a_cls}">{a_label}</span></td>
            <td><span class="al-module">{log.module}</span></td>
            <td>{entity}{detail_html}</td>
            <td class="al-ip">{log.ip_address or ''}</td>
        </tr>''')

    # Pagination
    pag = ""
    if total_pages > 1:
        pag = '<div style="display:flex;gap:4px;justify-content:center;margin-top:12px;">'
        if page > 1:
            pag += f'<button class="btn btn-sm btn-secondary" onclick="loadActivityLogs({page-1})"><i data-lucide="chevron-left"></i></button>'
        pag += f'<span style="padding:6px 12px;font-size:12px;color:#666;">Page {page}/{total_pages} ({total} entrées)</span>'
        if page < total_pages:
            pag += f'<button class="btn btn-sm btn-secondary" onclick="loadActivityLogs({page+1})"><i data-lucide="chevron-right"></i></button>'
        pag += '</div>'

    if not rows:
        html = '<div style="text-align:center;padding:40px;color:#888;"><i data-lucide="clipboard-list" style="width:32px;height:32px;"></i><p style="margin-top:8px;">Aucune activité enregistrée</p></div>'
    else:
        html = f'''<div class="table-container"><table class="data-table">
            <thead><tr>
                <th>Date</th><th>Utilisateur</th><th>Action</th><th>Module</th><th>Détails</th><th>IP</th>
            </tr></thead>
            <tbody>{"".join(rows)}</tbody>
        </table></div>{pag}'''

    return HTMLResponse(content=html)
