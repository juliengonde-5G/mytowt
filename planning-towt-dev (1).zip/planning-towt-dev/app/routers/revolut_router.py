"""
Revolut webhook + admin API routes.

Webhook: POST /api/revolut/webhook — receives Revolut event notifications
Admin:   POST /api/revolut/create-payment-link/{payment_id} — generate checkout URL
Admin:   POST /api/revolut/refresh/{payment_id} — poll latest status from Revolut
Portal:  GET  /api/revolut/pay/{payment_id}/{token} — redirect passenger to checkout
"""
import logging
from datetime import date
from typing import Optional

from fastapi import APIRouter, Request, Depends, HTTPException
from fastapi.responses import JSONResponse, RedirectResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload

from app.database import get_db
from app.auth import get_current_user
from app.models.user import User
from app.models.passenger import PassengerPayment, PassengerBooking, PassengerAuditLog
from app.utils.revolut import (
    create_order, get_order, verify_webhook_signature, map_revolut_state,
)

logger = logging.getLogger("revolut")

router = APIRouter(prefix="/api/revolut", tags=["revolut"])


# ═══════════════════════════════════════════════════════════════
#  WEBHOOK — called by Revolut (no auth, signature verified)
# ═══════════════════════════════════════════════════════════════
@router.post("/webhook")
async def revolut_webhook(request: Request, db: AsyncSession = Depends(get_db)):
    """
    Handle Revolut webhook events.
    Main event: ORDER_COMPLETED, ORDER_AUTHORISED, ORDER_PAYMENT_FAILED
    """
    body = await request.body()

    # Verify signature
    sig = request.headers.get("Revolut-Signature", "")
    if sig and not verify_webhook_signature(body, sig):
        logger.warning("Invalid Revolut webhook signature")
        raise HTTPException(401, "Invalid signature")

    try:
        payload = await request.json()
    except Exception:
        raise HTTPException(400, "Invalid JSON")

    event_type = payload.get("event", "")
    order_data = payload.get("order", payload)  # Some events nest under "order"

    # Extract order ID
    order_id = order_data.get("id") or order_data.get("order_id")
    if not order_id:
        logger.warning(f"Webhook without order_id: {event_type}")
        return JSONResponse({"status": "ignored"})

    revolut_state = order_data.get("state", "")
    logger.info(f"Revolut webhook: {event_type} — order={order_id} state={revolut_state}")

    # Find matching payment
    result = await db.execute(
        select(PassengerPayment).where(PassengerPayment.revolut_order_id == order_id)
    )
    payment = result.scalar_one_or_none()

    if not payment:
        logger.warning(f"No payment found for Revolut order {order_id}")
        return JSONResponse({"status": "no_match"})

    # Update payment status
    old_status = payment.status
    new_status = map_revolut_state(revolut_state)
    payment.status = new_status
    payment.revolut_state = revolut_state

    if new_status == "received" and not payment.paid_date:
        payment.paid_date = date.today()

    # Audit log
    if old_status != new_status:
        db.add(PassengerAuditLog(
            booking_id=payment.booking_id,
            action="revolut_payment_update",
            field_name=payment.payment_type,
            old_value=f"{old_status}",
            new_value=f"{new_status} (revolut: {revolut_state})",
            changed_by="Revolut Webhook",
        ))

    # Auto-update booking if payment completed
    if new_status == "received":
        booking = await db.get(PassengerBooking, payment.booking_id)
        if booking and booking.price_total:
            all_pay_result = await db.execute(
                select(PassengerPayment).where(PassengerPayment.booking_id == booking.id)
            )
            all_payments = all_pay_result.scalars().all()
            total_received = sum(
                float(p.amount) for p in all_payments
                if p.status == "received" or (p.id == payment.id)
            )
            if total_received >= float(booking.price_total) and booking.status in ("draft", "confirmed"):
                booking.status = "paid"
                db.add(PassengerAuditLog(
                    booking_id=booking.id,
                    action="status_change",
                    field_name="status",
                    old_value=booking.status,
                    new_value="paid",
                    changed_by="Revolut Webhook (auto)",
                ))

        # Create notification
        from app.models.notification import Notification
        db.add(Notification(
            type="payment_received",
            title=f"💳 Paiement CB reçu — {payment.reference or booking.reference if booking else ''}",
            detail=f"{float(payment.amount):.2f} € ({payment.payment_type})",
            link=f"/passengers/{payment.booking_id}#payments",
            booking_id=payment.booking_id,
        ))

    await db.commit()
    return JSONResponse({"status": "ok"})


# ═══════════════════════════════════════════════════════════════
#  ADMIN: Generate payment link for a payment entry
# ═══════════════════════════════════════════════════════════════
@router.post("/create-payment-link/{payment_id}")
async def create_payment_link(
    payment_id: int,
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Create a Revolut order for an existing PassengerPayment and store the checkout_url.
    Called by admin when they want to send a card payment link to the passenger.
    """
    payment = await db.get(PassengerPayment, payment_id)
    if not payment:
        raise HTTPException(404, "Paiement introuvable")

    if payment.revolut_order_id and payment.checkout_url:
        # Already has a link — check if it's still valid
        try:
            order = await get_order(payment.revolut_order_id)
            if order.get("state") in ("pending", "processing"):
                return JSONResponse({
                    "status": "existing",
                    "checkout_url": payment.checkout_url,
                    "revolut_order_id": payment.revolut_order_id,
                })
        except Exception:
            pass  # Order expired or error — create new one

    # Get booking for context
    booking = await db.execute(
        select(PassengerBooking).options(
            selectinload(PassengerBooking.passengers),
            selectinload(PassengerBooking.leg),
        ).where(PassengerBooking.id == payment.booking_id)
    )
    booking = booking.scalar_one_or_none()

    # Build description
    desc_parts = [f"TOWT — {payment.payment_type.capitalize()}"]
    if booking:
        desc_parts.append(f"Réf: {booking.reference}")
        if booking.leg:
            desc_parts.append(f"Voyage: {booking.leg.leg_code}")
    description = " · ".join(desc_parts)

    # Customer email
    customer_email = None
    if booking and booking.contact_email:
        customer_email = booking.contact_email
    elif booking and booking.passengers:
        for pax in booking.passengers:
            if pax.email:
                customer_email = pax.email
                break

    # Amount in minor units (cents)
    amount_cents = int(float(payment.amount) * 100)
    currency = payment.currency or "EUR"

    # Build redirect URL for after payment
    base_url = str(request.base_url).rstrip("/")
    redirect_url = None
    if booking:
        redirect_url = f"{base_url}/passenger/{booking.token}/payment-return?payment_id={payment.id}"

    try:
        order_data = await create_order(
            amount_cents=amount_cents,
            currency=currency,
            description=description,
            customer_email=customer_email,
            merchant_reference=booking.reference if booking else str(payment_id),
            redirect_url=redirect_url,
        )
    except Exception as e:
        logger.error(f"Revolut create_order failed: {e}")
        raise HTTPException(502, f"Erreur Revolut: {str(e)}")

    # Update payment record
    payment.revolut_order_id = order_data["id"]
    payment.checkout_url = order_data.get("checkout_url", "")
    payment.revolut_state = order_data.get("state", "pending")
    payment.payment_method = "revolut"
    payment.status = "pending"

    # Audit
    db.add(PassengerAuditLog(
        booking_id=payment.booking_id,
        action="revolut_link_created",
        field_name=payment.payment_type,
        old_value=None,
        new_value=f"{float(payment.amount):.2f}€ — {order_data['id'][:12]}...",
        changed_by=user.full_name,
    ))

    await db.commit()

    return JSONResponse({
        "status": "created",
        "checkout_url": order_data.get("checkout_url", ""),
        "revolut_order_id": order_data["id"],
    })


# ═══════════════════════════════════════════════════════════════
#  ADMIN: Refresh payment status from Revolut
# ═══════════════════════════════════════════════════════════════
@router.post("/refresh/{payment_id}")
async def refresh_payment_status(
    payment_id: int,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Poll Revolut for latest order status and update our record."""
    payment = await db.get(PassengerPayment, payment_id)
    if not payment:
        raise HTTPException(404)
    if not payment.revolut_order_id:
        raise HTTPException(400, "Ce paiement n'a pas de commande Revolut")

    try:
        order = await get_order(payment.revolut_order_id)
    except Exception as e:
        raise HTTPException(502, f"Erreur Revolut: {str(e)}")

    revolut_state = order.get("state", "")
    old_status = payment.status
    new_status = map_revolut_state(revolut_state)

    payment.revolut_state = revolut_state
    payment.status = new_status
    if new_status == "received" and not payment.paid_date:
        payment.paid_date = date.today()

    # Auto-update booking if fully paid
    if new_status == "received" and old_status != "received":
        booking = await db.get(PassengerBooking, payment.booking_id)
        if booking and booking.price_total:
            all_pay_result = await db.execute(
                select(PassengerPayment).where(PassengerPayment.booking_id == booking.id)
            )
            all_payments = all_pay_result.scalars().all()
            total_received = sum(float(p.amount) for p in all_payments if p.status == "received")
            if total_received >= float(booking.price_total) and booking.status in ("draft", "confirmed"):
                booking.status = "paid"

    await db.commit()

    return JSONResponse({
        "status": new_status,
        "revolut_state": revolut_state,
        "paid_date": str(payment.paid_date) if payment.paid_date else None,
    })


# ═══════════════════════════════════════════════════════════════
#  ADMIN: Create a new Revolut payment (one-click from booking)
# ═══════════════════════════════════════════════════════════════
@router.post("/create-revolut-payment/{booking_id}")
async def create_revolut_payment(
    booking_id: int,
    request: Request,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Create a PassengerPayment + Revolut order in one step.
    Form data: payment_type, amount, due_date (optional)
    """
    form = await request.form()
    payment_type = form.get("payment_type", "acompte")
    amount = float(form.get("amount", 0))
    due_date_str = form.get("due_date", "")

    if amount <= 0:
        raise HTTPException(400, "Montant invalide")

    booking_result = await db.execute(
        select(PassengerBooking).options(
            selectinload(PassengerBooking.passengers),
            selectinload(PassengerBooking.leg),
        ).where(PassengerBooking.id == booking_id)
    )
    booking = booking_result.scalar_one_or_none()
    if not booking:
        raise HTTPException(404)

    from datetime import datetime

    # Create payment record
    payment = PassengerPayment(
        booking_id=booking_id,
        payment_type=payment_type,
        payment_method="revolut",
        amount=amount,
        currency=booking.currency or "EUR",
        status="pending",
        reference=booking.reference,
        due_date=datetime.strptime(due_date_str, "%Y-%m-%d").date() if due_date_str.strip() else None,
    )
    db.add(payment)
    await db.flush()  # Get payment.id

    # Create Revolut order
    desc_parts = [f"TOWT — {payment_type.capitalize()}", f"Réf: {booking.reference}"]
    if booking.leg:
        desc_parts.append(f"Voyage: {booking.leg.leg_code}")
    description = " · ".join(desc_parts)

    customer_email = booking.contact_email
    if not customer_email and booking.passengers:
        for pax in booking.passengers:
            if pax.email:
                customer_email = pax.email
                break

    amount_cents = int(amount * 100)
    base_url = str(request.base_url).rstrip("/")
    redirect_url = f"{base_url}/passenger/{booking.token}/payment-return?payment_id={payment.id}"

    try:
        order_data = await create_order(
            amount_cents=amount_cents,
            currency=booking.currency or "EUR",
            description=description,
            customer_email=customer_email,
            merchant_reference=booking.reference,
            redirect_url=redirect_url,
        )
        payment.revolut_order_id = order_data["id"]
        payment.checkout_url = order_data.get("checkout_url", "")
        payment.revolut_state = order_data.get("state", "pending")
    except Exception as e:
        logger.error(f"Revolut create_order failed: {e}")
        # Keep the payment record but without Revolut link
        payment.notes = f"Erreur Revolut: {str(e)}"

    # Auto-set booking status
    if booking.status == "draft":
        booking.status = "confirmed"

    # Audit
    db.add(PassengerAuditLog(
        booking_id=booking_id,
        action="revolut_payment_created",
        field_name=payment_type,
        old_value=None,
        new_value=f"{amount:.2f}€ CB Revolut",
        changed_by=user.full_name,
    ))

    await db.commit()

    return RedirectResponse(url=f"/passengers/{booking_id}#payments", status_code=303)
