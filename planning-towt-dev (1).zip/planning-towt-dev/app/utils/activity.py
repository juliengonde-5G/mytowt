"""Activity logging helper — call from any router to log user actions."""
from app.models.activity_log import ActivityLog


async def log_activity(
    db,
    *,
    user=None,
    action: str,          # login, logout, create, update, delete, login_fail
    module: str,          # auth, commercial, passengers, cargo, crew, planning, escale, finance, claims, admin, onboard, kpi
    entity_type: str = None,   # order, booking, leg, user, claim, packing_list, crew_member, etc.
    entity_id=None,
    entity_label: str = None,
    detail: str = None,
    ip_address: str = None,
):
    """Log an activity. Commits immediately to avoid losing logs on later errors."""
    entry = ActivityLog(
        user_id=user.id if user else None,
        user_name=user.full_name if user else None,
        user_role=user.role if user else None,
        action=action,
        module=module,
        entity_type=entity_type,
        entity_id=str(entity_id) if entity_id is not None else None,
        entity_label=entity_label,
        detail=detail,
        ip_address=ip_address,
    )
    db.add(entry)
    # Flush to ensure log is written even if the route fails later
    try:
        await db.flush()
    except Exception:
        pass  # Never let logging break the main flow


def get_client_ip(request) -> str:
    """Extract client IP from request, handling reverse proxy headers."""
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    real_ip = request.headers.get("x-real-ip")
    if real_ip:
        return real_ip
    if request.client:
        return request.client.host
    return "unknown"
