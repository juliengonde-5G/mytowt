#!/usr/bin/env node
/**
 * Generate a Rate Offer DOCX for a Shipper client.
 * Usage: node generate_rate_offer.js <json_data_path> <output_path>
 */
const fs = require("fs");
const {
    Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
    Header, Footer, AlignmentType, HeadingLevel, BorderStyle, WidthType,
    ShadingType, PageBreak, PositionalTab, PositionalTabAlignment,
    PositionalTabRelativeTo, PositionalTabLeader, TabStopType,
    LevelFormat
} = require("docx");

const dataPath = process.argv[2];
const outputPath = process.argv[3];

if (!dataPath || !outputPath) {
    console.error("Usage: node generate_rate_offer.js <json_data> <output>");
    process.exit(1);
}

const data = JSON.parse(fs.readFileSync(dataPath, "utf-8"));

// ─── Colors ───
const TOWT_BLUE = "1B4F72";
const TOWT_LIGHT = "D6EAF8";
const HEADER_BG = "2E86C1";
const WHITE = "FFFFFF";
const GRAY_LIGHT = "F2F3F4";

// ─── Borders ───
const thinBorder = { style: BorderStyle.SINGLE, size: 1, color: "BDC3C7" };
const borders = { top: thinBorder, bottom: thinBorder, left: thinBorder, right: thinBorder };
const noBorder = { style: BorderStyle.NONE, size: 0 };
const noBorders = { top: noBorder, bottom: noBorder, left: noBorder, right: noBorder };

// ─── Cell helpers ───
const cellMargins = { top: 60, bottom: 60, left: 100, right: 100 };

function headerCell(text, width) {
    return new TableCell({
        borders,
        width: { size: width, type: WidthType.DXA },
        shading: { fill: HEADER_BG, type: ShadingType.CLEAR },
        margins: cellMargins,
        verticalAlign: "center",
        children: [new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [new TextRun({ text, bold: true, color: WHITE, font: "Arial", size: 18 })]
        })]
    });
}

function dataCell(text, width, opts = {}) {
    return new TableCell({
        borders,
        width: { size: width, type: WidthType.DXA },
        shading: opts.shading ? { fill: opts.shading, type: ShadingType.CLEAR } : undefined,
        margins: cellMargins,
        verticalAlign: "center",
        children: [new Paragraph({
            alignment: opts.align || AlignmentType.CENTER,
            children: [new TextRun({
                text: String(text),
                bold: opts.bold || false,
                font: "Arial",
                size: opts.size || 18,
                color: opts.color || "2C3E50"
            })]
        })]
    });
}

// ─── Build sections ───
const children = [];

// Title
children.push(new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 200 },
    children: [new TextRun({
        text: "RATE OFFER",
        bold: true, font: "Arial", size: 36, color: TOWT_BLUE
    })]
}));

// Subtitle with reference
children.push(new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 100 },
    children: [new TextRun({
        text: data.reference || "",
        font: "Arial", size: 22, color: "5D6D7E"
    })]
}));

// Client info
children.push(new Paragraph({ spacing: { before: 300, after: 100 },
    children: [new TextRun({ text: "Client: ", bold: true, font: "Arial", size: 22, color: TOWT_BLUE }),
               new TextRun({ text: data.client_name || "", font: "Arial", size: 22 })]
}));

if (data.client_contact) {
    children.push(new Paragraph({ spacing: { after: 100 },
        children: [new TextRun({ text: "Contact: ", bold: true, font: "Arial", size: 20, color: "5D6D7E" }),
                   new TextRun({ text: data.client_contact, font: "Arial", size: 20 })]
    }));
}

children.push(new Paragraph({ spacing: { after: 100 },
    children: [new TextRun({ text: "Validity: ", bold: true, font: "Arial", size: 20, color: "5D6D7E" }),
               new TextRun({ text: `${data.valid_from || ""} to ${data.valid_to || ""}`, font: "Arial", size: 20 })]
}));

// ─── Separator ───
children.push(new Paragraph({
    spacing: { before: 200, after: 200 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: TOWT_BLUE, space: 1 } },
    children: []
}));

// ─── RATES CONSTRUCTION ───
children.push(new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 200, after: 150 },
    children: [new TextRun({ text: "Rates Construction", bold: true, font: "Arial", size: 26, color: TOWT_BLUE })]
}));

const ratesConstructionItems = [
    "Our rates depend on the volume loaded per trip, with prices decreasing as the number of pallets increases.",
    "Our rates are based on 'Full Liner Terms' and include OTHC and DTHC, which covers the delivery of cargo to our POL warehouse and its collection from our bonded POD warehouse at the destination.",
    "Our rates are per pallet on the floor, considering EUROPALLETS (80\u00D7120 cm on the floor, with a maximum height of 190 cm).",
    "DG surcharge (if any) is included in the sea freight rates.",
    `Free time: 7 days at origin and 21 days at destination.`,
    `Validity: ${data.validity_date || data.valid_to || ""}`,
];

const ratesSubjectItems = [
    `BL fee: ${data.bl_fee != null ? "\u20AC" + Number(data.bl_fee).toFixed(2) : ""}`,
    `Booking fee: ${data.booking_fee != null ? "\u20AC" + Number(data.booking_fee).toFixed(2) : ""}`,
];

for (const item of ratesConstructionItems) {
    children.push(new Paragraph({
        numbering: { reference: "bullets", level: 0 },
        spacing: { after: 60 },
        children: [new TextRun({ text: item, font: "Arial", size: 20 })]
    }));
}

children.push(new Paragraph({
    numbering: { reference: "bullets", level: 0 },
    spacing: { after: 40 },
    children: [new TextRun({ text: "Rates are subject to:", font: "Arial", size: 20 })]
}));

for (const item of ratesSubjectItems) {
    children.push(new Paragraph({
        indent: { left: 1080, hanging: 360 },
        spacing: { after: 40 },
        children: [new TextRun({ text: "\u25CB  " + item, font: "Arial", size: 20 })]
    }));
}

// ─── NAVIGATION SCHEDULE ───
children.push(new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 300, after: 150 },
    children: [new TextRun({ text: "Navigation Schedule", bold: true, font: "Arial", size: 26, color: TOWT_BLUE })]
}));

if (data.lines && data.lines.length > 0) {
    // Navigation info table: POL | POD | Distance | Nav Days
    const navColWidths = [2200, 2200, 2200, 2760];
    const navTable = new Table({
        width: { size: 9360, type: WidthType.DXA },
        columnWidths: navColWidths,
        rows: [
            new TableRow({
                children: [
                    headerCell("POL", navColWidths[0]),
                    headerCell("POD", navColWidths[1]),
                    headerCell("Distance (NM)", navColWidths[2]),
                    headerCell("Navigation Days", navColWidths[3]),
                ]
            }),
            ...data.lines.map((line, i) => new TableRow({
                children: [
                    dataCell(line.pol_name || line.pol_locode, navColWidths[0], { shading: i % 2 ? GRAY_LIGHT : undefined }),
                    dataCell(line.pod_name || line.pod_locode, navColWidths[1], { shading: i % 2 ? GRAY_LIGHT : undefined }),
                    dataCell(line.distance_nm ? Math.round(line.distance_nm) : "-", navColWidths[2], { shading: i % 2 ? GRAY_LIGHT : undefined }),
                    dataCell(line.nav_days ? line.nav_days.toFixed(1) : "-", navColWidths[3], { shading: i % 2 ? GRAY_LIGHT : undefined }),
                ]
            }))
        ]
    });
    children.push(navTable);
}

// ─── RATES OFFER TABLE ───
children.push(new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 300, after: 150 },
    children: [new TextRun({ text: "Rates Offer", bold: true, font: "Arial", size: 26, color: TOWT_BLUE })]
}));

if (data.lines && data.lines.length > 0) {
    const rateColWidths = [1560, 1560, 1560, 1560, 1560, 1560];
    const rateTable = new Table({
        width: { size: 9360, type: WidthType.DXA },
        columnWidths: rateColWidths,
        rows: [
            new TableRow({
                children: [
                    headerCell("POL", rateColWidths[0]),
                    headerCell("POD", rateColWidths[1]),
                    headerCell("< 10 pallets", rateColWidths[2]),
                    headerCell("10-50 pallets", rateColWidths[3]),
                    headerCell("51-100 pallets", rateColWidths[4]),
                    headerCell("> 100 pallets", rateColWidths[5]),
                ]
            }),
            ...data.lines.map((line, i) => new TableRow({
                children: [
                    dataCell(line.pol_name || line.pol_locode, rateColWidths[0], { bold: true, shading: i % 2 ? GRAY_LIGHT : undefined }),
                    dataCell(line.pod_name || line.pod_locode, rateColWidths[1], { bold: true, shading: i % 2 ? GRAY_LIGHT : undefined }),
                    dataCell(line.rate_lt10 != null ? "\u20AC" + Number(line.rate_lt10).toFixed(2) : "-", rateColWidths[2], { shading: i % 2 ? GRAY_LIGHT : undefined }),
                    dataCell(line.rate_10to50 != null ? "\u20AC" + Number(line.rate_10to50).toFixed(2) : "-", rateColWidths[3], { shading: i % 2 ? GRAY_LIGHT : undefined }),
                    dataCell(line.rate_51to100 != null ? "\u20AC" + Number(line.rate_51to100).toFixed(2) : "-", rateColWidths[4], { shading: i % 2 ? GRAY_LIGHT : undefined }),
                    dataCell(line.rate_gt100 != null ? "\u20AC" + Number(line.rate_gt100).toFixed(2) : "-", rateColWidths[5], { shading: i % 2 ? GRAY_LIGHT : undefined }),
                ]
            }))
        ]
    });
    children.push(rateTable);
}

// ─── Additional notes ───
if (data.notes) {
    children.push(new Paragraph({
        heading: HeadingLevel.HEADING_1,
        spacing: { before: 300, after: 150 },
        children: [new TextRun({ text: "Additional Notes", bold: true, font: "Arial", size: 26, color: TOWT_BLUE })]
    }));
    children.push(new Paragraph({
        spacing: { after: 100 },
        children: [new TextRun({ text: data.notes, font: "Arial", size: 20 })]
    }));
}

// ─── Footer note ───
children.push(new Paragraph({
    spacing: { before: 400 },
    border: { top: { style: BorderStyle.SINGLE, size: 3, color: TOWT_BLUE, space: 1 } },
    children: []
}));
children.push(new Paragraph({
    spacing: { before: 100 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({
        text: "TOWT \u2014 Transport \u00E0 la Voile",
        font: "Arial", size: 16, color: "5D6D7E", italics: true
    })]
}));

// ─── Build document ───
const doc = new Document({
    numbering: {
        config: [{
            reference: "bullets",
            levels: [{
                level: 0, format: LevelFormat.BULLET, text: "\u2022",
                alignment: AlignmentType.LEFT,
                style: { paragraph: { indent: { left: 720, hanging: 360 } } }
            }]
        }]
    },
    styles: {
        default: { document: { run: { font: "Arial", size: 20 } } },
        paragraphStyles: [
            { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
              run: { size: 26, bold: true, font: "Arial", color: TOWT_BLUE },
              paragraph: { spacing: { before: 240, after: 120 }, outlineLevel: 0 } },
        ]
    },
    sections: [{
        properties: {
            page: {
                size: { width: 11906, height: 16838 }, // A4
                margin: { top: 1134, right: 1134, bottom: 1134, left: 1134 } // ~2cm
            }
        },
        headers: {
            default: new Header({
                children: [new Paragraph({
                    alignment: AlignmentType.RIGHT,
                    children: [new TextRun({
                        text: `TOWT \u2014 Rate Offer ${data.reference || ""}`,
                        font: "Arial", size: 16, color: "95A5A6", italics: true
                    })]
                })]
            })
        },
        footers: {
            default: new Footer({
                children: [new Paragraph({
                    alignment: AlignmentType.CENTER,
                    children: [new TextRun({
                        text: "Confidential \u2014 For intended recipient only",
                        font: "Arial", size: 14, color: "95A5A6", italics: true
                    })]
                })]
            })
        },
        children
    }]
});

Packer.toBuffer(doc).then(buffer => {
    fs.writeFileSync(outputPath, buffer);
    console.log("OK:" + outputPath);
}).catch(err => {
    console.error("ERROR:" + err.message);
    process.exit(1);
});
