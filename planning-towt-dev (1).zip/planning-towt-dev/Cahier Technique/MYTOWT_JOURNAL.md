# my_TOWT — Journal Technique Complet
# Dernière mise à jour : 2026-02-19
# Ce fichier est la référence pour reprendre le développement dans une nouvelle conversation.

## INFRASTRUCTURE
- Docker sur Synology NAS (towt-app-v2 container)
- FastAPI + Jinja2 + HTMX + PostgreSQL
- Auth: JWT cookies, bcrypt passwords
- i18n: FR/EN/ES/PT-BR/VI
- Permissions: 6 rôles × 8 modules (matrice dans permissions.py)
- Branding: "my_TOWT" (bleu #095561, vert #87BD2B)

## DÉPLOIEMENT TYPE
```bash
sudo docker cp <fichier> towt-app-v2:/app/app/<chemin>
sudo docker restart towt-app-v2
```

## STRUCTURE FICHIERS
```
app/
├── main.py              # FastAPI app, router registration
├── auth.py              # JWT auth, get_current_user
├── database.py          # AsyncSession, engine
├── config.py            # Settings
├── permissions.py       # Role/module permission matrix
├── templating.py        # Jinja2 env, custom filters (eur, flag_emoji)
├── i18n/                # Translations
├── models/
│   ├── __init__.py      # All model imports
│   ├── user.py          # User (auth, role, language)
│   ├── vessel.py        # Vessel (code, name, imo, dwt, capacity, speed)
│   ├── port.py          # Port (locode, name, country, lat/lon)
│   ├── leg.py           # Leg (vessel, ports, dates, status, year, leg_code)
│   ├── order.py         # Order + OrderAssignment (commercial)
│   ├── crew.py          # CrewMember + CrewAssignment
│   ├── operation.py     # EscaleOperation + DockerShift
│   ├── finance.py       # LegFinance + PortConfig + OpexParameter
│   ├── kpi.py           # LegKPI (emissions)
│   ├── emission_parameter.py
│   ├── onboard.py       # SofEvent + OnboardNotification + CargoDocument + SOF_EVENT_TYPES
│   ├── packing_list.py  # PackingList + PackingBatch
│   └── passenger.py     # PassengerBooking + Passenger + PassengerPayment + PassengerDocument + PreBoardingForm + CabinPriceGrid
├── routers/
│   ├── auth_router.py         # Login/logout
│   ├── dashboard_router.py    # Dashboard home
│   ├── admin_router.py        # Settings, users, vessels, ports, pricing grid
│   ├── planning_router.py     # Legs CRUD, Gantt, map, PDF commercial
│   ├── commercial_router.py   # Orders, assignments
│   ├── escale_router.py       # Port operations, docker shifts
│   ├── finance_router.py      # Financial KPIs per leg, PDF export
│   ├── kpi_router.py          # Emission KPIs
│   ├── crew_router.py         # Crew members, assignments
│   ├── onboard_router.py      # On Board: SOF, cargo docs, notifications
│   ├── cargo_router.py        # Packing lists, BOL, external client access (/p/{token})
│   ├── passenger_router.py    # Passenger bookings CRUD, payments, book PDF
│   ├── passenger_ext_router.py # External passenger portal (/passenger/{token})
│   └── api_ports.py           # Port search JSON API
├── utils/
│   └── crossing_book.py       # Crossing book PDF generator (bilingual FR/EN)
└── templates/
    ├── base.html               # Layout, sidebar, topbar
    ├── dashboard.html
    ├── auth/login.html
    ├── admin/settings.html, users.html, user_form.html, vessel_form.html
    ├── planning/index.html, leg_form.html, pdf_commercial.html, port_conflicts.html
    ├── commercial/index.html, order_form.html, assign_form.html
    ├── escale/index.html, operation_form.html, docker_form.html, pdf_export.html
    ├── finance/index.html, edit_form.html, port_config.html, port_config_form.html
    ├── kpi/index.html
    ├── crew/index.html, member_form.html, assign_form.html, calendar.html
    ├── onboard/index.html, doc_form.html
    ├── cargo/index.html, detail.html, client_form.html, bill_of_lading.html, history.html
    └── passengers/index.html, booking_form.html, detail.html, external.html
```

## TABLES DB (PostgreSQL)
users, vessels, ports, legs, orders, order_assignments,
crew_members, crew_assignments, escale_operations, docker_shifts,
leg_finances, port_configs, opex_parameters, leg_kpis, emission_parameters,
sof_events, onboard_notifications, cargo_documents,
packing_lists, packing_batches,
passenger_bookings, passengers, passenger_payments, passenger_documents,
preboarding_forms, cabin_price_grid

## MODULES — ÉTAT ACTUEL

### 1. Dashboard ✅
- Vessel status cards (en mer/à quai)
- KPI cards (CO2 avoided, fill rate)
- Upcoming legs, alerts

### 2. Planning ✅
- Leg CRUD, auto leg_code, auto ETD/ETA calc
- Table + Gantt views, map (Leaflet)
- PDF commercial export (with logo, i18n)
- Leg locking, completed greying

### 3. Commercial ✅
- Order CRUD with palette formats + coefficients
- Multi-leg assignment with route filtering
- Booking/documentation fees
- File attachments

### 4. Escale ✅
- Port operations by category (Navigation, Cargo, Relations Externes)
- Docker shifts with productivity
- Port status progression (3 states)
- PDF SOF export
- Leg locking

### 5. Finance ✅
- Per-leg P&L (revenue cargo + pax, port/quay/sea/ops costs)
- Auto-defaults from port config + OPEX
- Revenue includes cargo orders + passenger bookings
- Breakdown: 🚢 Cargo / 🧳 Passagers
- PDF export

### 6. KPI ✅
- Emission calculations (CO2 avoided)
- Auto-update from orders

### 7. Crew ✅
- Member CRUD (7 roles)
- Assignment per vessel, embark/debark tracking
- Calendar view

### 8. On Board ✅
- SOF events (3 groups: Navigation, Cargo, Passenger Operations)
- Cargo document generation (13 types, Word/PDF)
- Passengers section (cabin map, doc progress, emergency contacts)
- Notifications

### 9. Cargo Documentation ✅
- Packing lists + batches
- External client access (/p/{token})
- Bill of Lading generation
- Excel import/export
- Audit trail

### 10. Passagers ✅
- Booking = 1 cabine + 1 leg (obligatoire), 1 ou 2 passagers
- 4 cabines: 2 double + 2 twin = 8 pax max
- Pricing grid (route × cabin type) dans admin Settings
- Auto-pricing depuis la grille
- Workflow: draft → confirmed → paid → embarked → completed
- Paiements virement (boutons rapides acompte/solde, auto-status)
- Architecture prête pour Revolut Business (revolut_order_id)
- Portail externe bilingue (/passenger/{token}?lang=fr|en)
- Upload documents (6 types requis par passager)
- Questionnaire pré-embarquement (santé, expérience, régime)
- Book de traversée PDF bilingue (contenu réel TOWT)
- SOF: 4 événements passagers (embark, disembark, safety drill, muster)
- KPI financiers: revenus passagers intégrés

## CE QUI RESTE À FAIRE (IDEAS)
- Revolut Business API integration (quand clés API dispo)
- Email notifications (confirmation booking, rappel docs, rappel paiement)
- Passenger manifest PDF (liste pour capitainerie)
- Mobile optimization du portail passager
- Analytics / reporting cross-modules
- API REST pour intégrations externes
