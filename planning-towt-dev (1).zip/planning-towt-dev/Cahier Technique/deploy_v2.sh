#!/bin/bash
set -e

echo "=== 1/4 — Migration SQL ==="
sudo docker exec towt-app-v2 python3 -c "
import asyncio
from app.database import engine
from sqlalchemy import text
async def migrate():
    async with engine.begin() as conn:
        # Insurance contracts
        await conn.execute(text('''
            CREATE TABLE IF NOT EXISTS insurance_contracts (
                id SERIAL PRIMARY KEY,
                guarantee_type VARCHAR(30) UNIQUE NOT NULL,
                insurer_name VARCHAR(200) NOT NULL,
                insurer_email VARCHAR(200),
                insurer_phone VARCHAR(50),
                insurer_address TEXT,
                broker_reference VARCHAR(100),
                franchise_amount FLOAT DEFAULT 0,
                guarantee_ceiling FLOAT DEFAULT 0,
                policy_number VARCHAR(100),
                notes TEXT,
                is_active BOOLEAN DEFAULT TRUE,
                updated_at TIMESTAMPTZ DEFAULT NOW()
            )
        '''))
        print('OK insurance_contracts')

        # Claims
        await conn.execute(text('''
            CREATE TABLE IF NOT EXISTS claims (
                id SERIAL PRIMARY KEY,
                reference VARCHAR(30) UNIQUE NOT NULL,
                claim_type VARCHAR(20) NOT NULL,
                status VARCHAR(20) NOT NULL DEFAULT 'open',
                vessel_id INTEGER NOT NULL REFERENCES vessels(id),
                leg_id INTEGER NOT NULL REFERENCES legs(id),
                order_assignment_id INTEGER REFERENCES order_assignments(id),
                crew_member_id INTEGER REFERENCES crew_members(id),
                passenger_id INTEGER REFERENCES passengers(id),
                context VARCHAR(30),
                incident_date TIMESTAMPTZ,
                incident_location VARCHAR(200),
                description TEXT NOT NULL,
                guarantee_type VARCHAR(20),
                responsibility VARCHAR(20) DEFAULT 'pending',
                provision_amount NUMERIC(12,2),
                franchise_amount NUMERIC(12,2),
                indemnity_amount NUMERIC(12,2),
                company_charge NUMERIC(12,2),
                currency VARCHAR(3) DEFAULT 'EUR',
                sof_event_id INTEGER REFERENCES sof_events(id),
                declared_by VARCHAR(200),
                closed_at TIMESTAMPTZ,
                notes TEXT,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                updated_at TIMESTAMPTZ DEFAULT NOW()
            )
        '''))
        print('OK claims')

        # Claim documents
        await conn.execute(text('''
            CREATE TABLE IF NOT EXISTS claim_documents (
                id SERIAL PRIMARY KEY,
                claim_id INTEGER NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
                doc_type VARCHAR(30) NOT NULL,
                title VARCHAR(300) NOT NULL,
                filename VARCHAR(300),
                file_path VARCHAR(500),
                notes TEXT,
                uploaded_by VARCHAR(200),
                created_at TIMESTAMPTZ DEFAULT NOW()
            )
        '''))
        print('OK claim_documents')

        # Claim timeline
        await conn.execute(text('''
            CREATE TABLE IF NOT EXISTS claim_timeline (
                id SERIAL PRIMARY KEY,
                claim_id INTEGER NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
                action_type VARCHAR(30) NOT NULL,
                title VARCHAR(300) NOT NULL,
                description TEXT,
                old_value VARCHAR(100),
                new_value VARCHAR(100),
                filename VARCHAR(300),
                file_path VARCHAR(500),
                actor VARCHAR(200) NOT NULL,
                action_date TIMESTAMPTZ,
                created_at TIMESTAMPTZ DEFAULT NOW()
            )
        '''))
        print('OK claim_timeline')

        # Indexes
        for idx in ['CREATE INDEX IF NOT EXISTS idx_claims_vessel ON claims(vessel_id)',
                     'CREATE INDEX IF NOT EXISTS idx_claims_leg ON claims(leg_id)',
                     'CREATE INDEX IF NOT EXISTS idx_claims_type ON claims(claim_type)',
                     'CREATE INDEX IF NOT EXISTS idx_claim_docs ON claim_documents(claim_id)',
                     'CREATE INDEX IF NOT EXISTS idx_claim_tl ON claim_timeline(claim_id)']:
            await conn.execute(text(idx))

        # Add claims_cost to leg_finances if missing
        try:
            await conn.execute(text('ALTER TABLE leg_finances ADD COLUMN IF NOT EXISTS claims_cost FLOAT DEFAULT 0'))
            print('OK claims_cost on leg_finances')
        except: pass

        # Ensure passenger_audit_logs
        await conn.execute(text('''CREATE TABLE IF NOT EXISTS passenger_audit_logs (id SERIAL PRIMARY KEY, booking_id INTEGER NOT NULL REFERENCES passenger_bookings(id) ON DELETE CASCADE, passenger_id INTEGER, action VARCHAR(100) NOT NULL, field_name VARCHAR(100), old_value TEXT, new_value TEXT, changed_by VARCHAR(200) NOT NULL, changed_at TIMESTAMPTZ DEFAULT NOW())'''))

        # Create claims upload dir
        import os; os.makedirs('/app/data/claims', exist_ok=True)
        print('OK all migrations')

asyncio.run(migrate())
"

echo "=== 2/4 — Extraction locale ==="
python3 -c "
import zipfile, os
z = zipfile.ZipFile(os.path.expanduser('~/app_modified.zip'))
z.extractall('/tmp/app_extract')
z.close()
print('OK')
"

echo "=== 3/4 — Copie dans le container ==="
sudo docker cp /tmp/app_extract/. towt-app-v2:/app/app/

echo "=== 4/4 — Restart ==="
rm -rf /tmp/app_extract
sudo docker restart towt-app-v2

echo ""
echo "=== Deploiement v2 termine ==="
echo "Nouveautes:"
echo "  - Claims: upload PJ, centre documentaire, calcul auto finance"
echo "  - Claims: Gantt, declaration PDF"
echo "  - Parametres: contrats d assurance"
