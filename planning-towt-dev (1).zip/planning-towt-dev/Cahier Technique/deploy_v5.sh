#!/bin/bash
set -e
CONTAINER="towt-app-v2"
ZIP_SOURCE="/volume1/homes/admin.5g/app_modified.zip"

echo "=== Deploy v5: Portail passager complet ==="

sudo docker cp "$ZIP_SOURCE" $CONTAINER:/tmp/app_update.zip

sudo docker exec $CONTAINER python3 -c "
import zipfile
with zipfile.ZipFile('/tmp/app_update.zip','r') as z:
    z.extractall('/tmp/app_extract')
"

# Create portal_messages table
sudo docker exec $CONTAINER python3 -c "
import asyncio
from app.database import engine
from sqlalchemy import text

async def migrate():
    async with engine.begin() as conn:
        await conn.execute(text('''
            CREATE TABLE IF NOT EXISTS portal_messages (
                id SERIAL PRIMARY KEY,
                booking_id INTEGER REFERENCES passenger_bookings(id) ON DELETE CASCADE,
                packing_list_id INTEGER REFERENCES packing_lists(id) ON DELETE CASCADE,
                sender_type VARCHAR(20) NOT NULL,
                sender_name VARCHAR(200) NOT NULL,
                message TEXT NOT NULL,
                is_read BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMPTZ DEFAULT NOW()
            )
        '''))
    print('  ✓ portal_messages table ready')

asyncio.run(migrate())
"

FILES=(
    routers/passenger_router.py
    routers/passenger_ext_router.py
    routers/kpi_router.py
    routers/claim_router.py
    models/portal_message.py
    templates/passengers/portal_base.html
    templates/passengers/portal_admin.html
    templates/passengers/portal_vessel.html
    templates/passengers/portal_voyage.html
    templates/passengers/portal_life.html
    templates/passengers/portal_safety.html
    templates/passengers/portal_docs.html
    templates/passengers/portal_messages.html
    templates/passengers/detail.html
    templates/cargo/detail.html
    templates/cargo/client_form.html
    templates/kpi/index.html
    templates/admin/settings.html
    templates/claims/detail.html
    i18n/__init__.py
)

for f in "${FILES[@]}"; do
    sudo docker exec $CONTAINER mkdir -p "/app/app/$(dirname $f)" 2>/dev/null
    sudo docker exec $CONTAINER cp /tmp/app_extract/$f /app/app/$f 2>/dev/null && echo "  ✓ $f" || echo "  ⚠ $f (skipped)"
done

sudo docker exec $CONTAINER pkill -f uvicorn || true
sleep 2
sudo docker exec -d $CONTAINER uvicorn app.main:app --host 0.0.0.0 --port 8000
sleep 3

echo ""
echo "=== Deployment complete ==="
echo ""
echo "Portail passager:"
echo "  ✓ Logo TOWT dans le header"
echo "  ✓ Sidebar navigation avec 7 pages"
echo "  ✓ Page Administratif (ancienne page principale)"
echo "  ✓ Page Le Navire"
echo "  ✓ Page Le Voyage (ports, calendrier, équipage)"
echo "  ✓ Page Vie à bord"
echo "  ✓ Page Sécurité à bord"
echo "  ✓ Page Documentation contractuelle"
echo "  ✓ Page Messagerie (fil de discussion)"
echo "  ✓ Responsive mobile (sidebar rétractable)"
echo ""
echo "Backoffice passagers:"
echo "  ✓ Modifier/supprimer paiements (hors CB)"
echo "  ✓ Upload/download documents"
echo "  ✓ Lien avec port :8081"
echo ""
echo "Cargo:"
echo "  ✓ Lien avec port :8081"
echo "  ✓ Traductions corrigées"
