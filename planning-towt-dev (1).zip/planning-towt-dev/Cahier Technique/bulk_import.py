"""
Bulk import satcom CSV archives into vessel_positions table.
Runs INSIDE the Docker container. Processes files in batches for performance.
"""
import os
import sys
import csv
import re
import io
import time
from datetime import datetime, timezone

# Add app to path
sys.path.insert(0, '/app')

import psycopg2

# --- Config ---
ARCHIVE_DIR = "/tmp/satcom_archives"
DB_URL = os.environ.get("DATABASE_URL", "postgresql://towt:towt@db:5432/towt")

# Parse DB URL
import re as _re
m = _re.match(r'postgresql(?:\+\w+)?://([^:]+):([^@]+)@([^:]+):(\d+)/(.+)', DB_URL)
if not m:
    print(f"ERROR: Cannot parse DATABASE_URL: {DB_URL}")
    sys.exit(1)

DB_PARAMS = {
    "user": m.group(1),
    "password": m.group(2),
    "host": m.group(3),
    "port": int(m.group(4)),
    "dbname": m.group(5),
}


def extract_vessel_name(filename):
    """Extract vessel name from filename like '20260226090502-anemos-satcoms.csv'."""
    name = filename.lower()
    name = re.sub(r"^\d{14}-?", "", name)
    name = re.sub(r"-?satcoms.*$", "", name)
    return name.strip("-_ ")


def parse_csv(filepath):
    """Parse a satcom CSV file into position dicts."""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
    except UnicodeDecodeError:
        with open(filepath, 'r', encoding='latin-1') as f:
            content = f.read()

    reader = csv.DictReader(io.StringIO(content), delimiter=";")
    positions = []
    for row in reader:
        try:
            date_str = row.get("Date", "").strip()
            if not date_str:
                continue
            dt = datetime.fromisoformat(date_str)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)

            lat = float(row.get("Latitude", "0").strip())
            lon = float(row.get("Longitude", "0").strip())

            sog_str = row.get("SOG (knots)", "").strip()
            cog_str = row.get("COG (degree)", "").strip()
            sog = float(sog_str) if sog_str else None
            cog = float(cog_str) if cog_str else None

            source = row.get("Active interface", "").strip() or None

            positions.append((dt, lat, lon, sog, cog, source))
        except (ValueError, KeyError):
            continue
    return positions


def main():
    start = time.time()

    # Connect to DB
    conn = psycopg2.connect(**DB_PARAMS)
    conn.autocommit = False
    cur = conn.cursor()

    # Load vessels (name -> id mapping, case-insensitive)
    cur.execute("SELECT id, LOWER(name) FROM vessels")
    vessels_db = {name: vid for vid, name in cur.fetchall()}
    print(f"Vessels in DB: {vessels_db}")

    # Load legs for leg matching (vessel_id -> list of legs)
    cur.execute("""
        SELECT id, vessel_id, etd, eta, atd, ata 
        FROM legs 
        ORDER BY vessel_id, sequence
    """)
    legs_by_vessel = {}
    for lid, vid, etd, eta, atd, ata in cur.fetchall():
        legs_by_vessel.setdefault(vid, []).append({
            "id": lid, "etd": etd, "eta": eta, "atd": atd, "ata": ata
        })
    print(f"Loaded legs for {len(legs_by_vessel)} vessels")

    # Collect all CSV files
    csv_files = sorted([
        f for f in os.listdir(ARCHIVE_DIR)
        if f.lower().endswith('.csv')
    ])
    total_files = len(csv_files)
    print(f"\nProcessing {total_files} CSV files...")

    # Stats
    total_inserted = 0
    total_skipped = 0
    total_errors = 0
    files_ok = 0
    files_err = 0
    vessel_not_found = set()

    # Leg matching cache (vessel_id, hour_key -> leg_id)
    leg_cache = {}

    def match_leg(vessel_id, dt):
        """Match a position to a leg based on dates."""
        hour_key = (vessel_id, dt.strftime("%Y-%m-%d-%H"))
        if hour_key in leg_cache:
            return leg_cache[hour_key]

        legs = legs_by_vessel.get(vessel_id, [])
        matched = None

        # Make dt offset-aware for comparison
        if dt.tzinfo is None:
            dt_aware = dt.replace(tzinfo=timezone.utc)
        else:
            dt_aware = dt

        # Priority 1: ATD <= dt <= ATA
        for leg in legs:
            if leg["atd"] and leg["atd"] <= dt_aware:
                if leg["ata"] is None or leg["ata"] >= dt_aware:
                    matched = leg["id"]
                    break

        # Priority 2: ETD <= dt <= ETA
        if not matched:
            for leg in legs:
                if leg["etd"] and leg["etd"] <= dt_aware:
                    if leg["eta"] is None or leg["eta"] >= dt_aware:
                        matched = leg["id"]
                        break

        # Priority 3: nearest leg before date
        if not matched:
            best = None
            best_diff = None
            for leg in legs:
                end_date = leg["ata"] or leg["eta"]
                if end_date and end_date <= dt_aware:
                    diff = (dt_aware - end_date).total_seconds()
                    if best_diff is None or diff < best_diff:
                        best_diff = diff
                        best = leg["id"]
            matched = best

        leg_cache[hour_key] = matched
        return matched

    # Process files in batches
    BATCH_SIZE = 500
    batch_values = []

    INSERT_SQL = """
        INSERT INTO vessel_positions (vessel_id, leg_id, latitude, longitude, sog, cog, recorded_at, source, import_batch)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (vessel_id, recorded_at) DO NOTHING
    """

    for idx, filename in enumerate(csv_files):
        filepath = os.path.join(ARCHIVE_DIR, filename)

        # Extract vessel name
        v_name = extract_vessel_name(filename)
        if not v_name:
            files_err += 1
            continue

        # Find vessel ID (try partial match)
        vessel_id = None
        for db_name, vid in vessels_db.items():
            if v_name in db_name or db_name in v_name:
                vessel_id = vid
                break

        if not vessel_id:
            if v_name not in vessel_not_found:
                vessel_not_found.add(v_name)
                print(f"  WARNING: Vessel '{v_name}' not found in DB (from {filename})")
            files_err += 1
            continue

        # Parse CSV
        positions = parse_csv(filepath)
        if not positions:
            files_err += 1
            continue

        # Add to batch
        for dt, lat, lon, sog, cog, source in positions:
            leg_id = match_leg(vessel_id, dt)
            batch_values.append((vessel_id, leg_id, lat, lon, sog, cog, dt, source, filename))

        files_ok += 1

        # Execute batch when large enough
        if len(batch_values) >= BATCH_SIZE:
            try:
                cur.executemany(INSERT_SQL, batch_values)
                inserted = cur.rowcount
                total_inserted += inserted
                total_skipped += len(batch_values) - inserted
                conn.commit()
            except Exception as e:
                print(f"  DB ERROR: {e}")
                conn.rollback()
                total_errors += len(batch_values)
            batch_values = []

        # Progress
        if (idx + 1) % 1000 == 0:
            elapsed = time.time() - start
            rate = (idx + 1) / elapsed
            remaining = (total_files - idx - 1) / rate if rate > 0 else 0
            print(f"  [{idx+1}/{total_files}] {files_ok} OK, {files_err} err | "
                  f"{total_inserted} pts inserted | "
                  f"{elapsed:.0f}s elapsed, ~{remaining:.0f}s remaining")

    # Flush remaining batch
    if batch_values:
        try:
            cur.executemany(INSERT_SQL, batch_values)
            inserted = cur.rowcount
            total_inserted += inserted
            total_skipped += len(batch_values) - inserted
            conn.commit()
        except Exception as e:
            print(f"  DB ERROR: {e}")
            conn.rollback()
            total_errors += len(batch_values)

    elapsed = time.time() - start
    cur.close()
    conn.close()

    print(f"\n{'='*50}")
    print(f"IMPORT COMPLETE in {elapsed:.1f}s")
    print(f"{'='*50}")
    print(f"Files:    {total_files} total | {files_ok} OK | {files_err} errors")
    print(f"Points:   {total_inserted} inserted | {total_skipped} duplicates skipped | {total_errors} errors")
    if vessel_not_found:
        print(f"Vessels not found: {', '.join(sorted(vessel_not_found))}")
    print(f"{'='*50}")


if __name__ == "__main__":
    main()
