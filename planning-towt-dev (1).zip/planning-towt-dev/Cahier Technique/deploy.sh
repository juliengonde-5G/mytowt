#!/bin/bash
set -e

echo "=== 1/3 — Extraction locale ==="
python3 -c "
import zipfile, os
z = zipfile.ZipFile(os.path.expanduser('~/app_modified.zip'))
z.extractall('/tmp/app_extract')
z.close()
print('OK extrait')
"

echo "=== 2/3 — Copie dans le container ==="
sudo docker cp /tmp/app_extract/. towt-app-v2:/app/app/

echo "=== 3/3 — Restart ==="
rm -rf /tmp/app_extract
sudo docker restart towt-app-v2

echo ""
echo "Deploiement termine"
