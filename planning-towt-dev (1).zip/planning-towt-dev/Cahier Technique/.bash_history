sudo docker stop towt-app-dev
sudo docker rm towt-app-dev
# Créer NOUVEAU conteneur APP propre
sudo docker run -d   --name towt-app-new   -p 8081:5000   -v /volume1/docker/planning-towt-dev:/app   --link towt-db-dev:db   python:3.9   bash -c "pip install flask psycopg2-binary && cd /app && python3 app.py"
sleep 10
echo "✅ NOUVEAU conteneur towt-app-new lancé!"
echo ""
echo "🌐 TESTEZ: http://IP_SYNO:8081/"
sudo docker stop towt-app-new 2>/dev/null || true
sudo docker rm towt-app-new 2>/dev/null || true
# Récupérer réseau du conteneur DB
NETWORK=\$(sudo docker inspect towt-db-dev --format '{{range .NetworkSettings.Networks}}{{.NetworkID}}{{end}}')
sudo docker run -d   --name towt-app-new   -p 8081:5000   --network container:towt-db-dev   -v /volume1/docker/planning-towt-dev:/app   python:3.9   bash -c "pip install flask psycopg2-binary python-dotenv && cd /app && python3 app.py"
sleep 15
echo "✅ towt-app-new lancé sur réseau DB!"
echo ""
echo "🌐 http://IP_SYNO:8081/"
sudo docker rm -f towt-app-new 2>/dev/null || true
sudo docker run -d   --name towt-app-new   -p 8082:5000   --network bridge   -e POSTGRES_HOST=towt-db-dev   -e POSTGRES_DB=towt_planning   -e POSTGRES_USER=towt_user   -v /volume1/docker/planning-towt-dev:/app   python:3.9   bash -c "
pip install flask psycopg2-binary python-dotenv && 
cd /app && 
python3 app.py
"
sleep 20
echo "✅ towt-app-new sur port 8082!"
echo "🌐 http://IP_SYNO:8082/"
sudo docker rm -f towt-app-new 2>/dev/null || true
sudo docker run -d   --name towt-app-new   -p 8082:5000   python:3.9   tail -f /dev/null
# Copier TOUS les fichiers
sudo docker cp /volume1/docker/planning-towt-dev/. towt-app-new:/app/
# Installer deps
sudo docker exec towt-app-new pip install flask psycopg2-binary python-dotenv
# Lancer app
sudo docker exec -d towt-app-new bash -c "cd /app && python3 app.py"
sleep 10
echo "✅ App copiée + lancée sur 8082!"
echo "🌐 http://IP_SYNO:8082/"
sudo docker logs towt-app-new --tail 50
sudo docker exec -it towt-app-new bash
sudo docker exec towt-app-new bash -c "
cat > /app/app.py << 'EOF'
from flask import Flask, render_template, jsonify
import sys
sys.path.insert(0, '/app')
from 02_config import db_config
from app.services.planning_service import PlanningService
from app.services.operations_service import OperationsService

app = Flask(__name__)

@app.route('/')
def home():
    return '''
    <h1>🚢 TOWT Planning Nouvelle Version</h1>
    <p><a href="/planning">📊 Timeline Planning</a></p>
    <p><a href="/api/timeline">🔗 API Timeline JSON</a></p>
    '''

@app.route('/planning')
def planning():
    return render_template('planning.html')

@app.route('/api/timeline')
def timeline():
    # Mock data
    return jsonify({
        'voyages': [
            {'id': 1, 'name': 'V001-ANEMOS', 'ship_code': 1, 'port_calls': [
                {'call_id': '1-A-FRFEC-BRSSO-26', 'dep_iso': 'FRFEC', 'arr_iso': 'BRSSO'}
            ]}
        ]
    })

if __name__ == '__main__':
    print('🚀 TOWT Planning démarré sur http://0.0.0.0:5000')
    app.run(host='0.0.0.0', port=5000, debug=True)
EOF

# Créer templates
mkdir -p /app/templates /app/static/js

echo '✅ app.py principal créé!'
"
echo "App prête!"
sudo docker exec -d towt-app-new python3 /app/app.py
sudo docker logs towt-app-new --tail 20
sudo docker exec towt-app-new ps aux | grep python
echo "Copiez-moi les logs ET le ps!"
sudo docker logs towt-app-new --tail 20
sudo docker exec towt-app-new ps aux | grep python
sudo docker exec -it towt-app-new bash -c "cd /app && ls -la && python3 -c \"from app import app; print('App OK')\""
sudo docker exec towt-app-new bash -c "
cat > /app/app_minimal.py << 'EOF'
from flask import Flask
app = Flask(__name__)

@app.route('/')
def home():
    return '<h1>🚢 TOWT Planning NOUVELLE VERSION!</h1><p>Phase 1 Backend OK!</p>'

@app.route('/planning')
def planning():
    return '<h1>📊 Timeline Planning</h1><p>UI en construction...</p>'

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
EOF

python3 /app/app_minimal.py
EOF
"
# ========================================
# ÉTAPE 6.1: Ajouter Timeline UI
# ========================================
sudo docker exec towt-app-new bash -c "
cat > /app/templates/planning.html << 'EOF'
<html>
<head>
    <title>TOWT Planning Timeline</title>
    <style>
        body { font-family: Arial; margin: 20px; }
        #timeline { height: 500px; border: 2px solid #4CAF50; position: relative; overflow-x: auto; }
        .voyage { position: absolute; background: #2196F3; color: white; padding: 8px; border-radius: 5px; font-weight: bold; }
        .leg { position: absolute; height: 25px; background: linear-gradient(90deg, #FF9800, #FF5722); margin: 5px 0; border-radius: 3px; }
        .port { position: absolute; background: white; border: 1px solid #ddd; padding: 2px 6px; font-size: 12px; border-radius: 3px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        button { background: #4CAF50; color: white; border: none; padding: 10px 20px; margin: 5px; border-radius: 5px; cursor: pointer; }
        button:hover { background: #45a049; }
        #status { margin: 10px 0; padding: 10px; background: #f0f0f0; border-radius: 5px; }
    </style>
</head>
<body>
    <h1>🚢 TOWT Planning - Timeline Interactif</h1>
    
    <div>
        <select id='shipFilter'>
            <option value=''>Tous navires</option>
            <option value='1'>Anemos (1)</option>
            <option value='2'>Artemis (2)</option>
            <option value='3'>Atlantis (3)</option>
            <option value='4'>Atlas (4)</option>
        </select>
        <button onclick='loadData()'>🔄 Rafraîchir</button>
        <button onclick='checkCollisions()'>🔍 Vérifier collisions</button>
        <button onclick='exportPlanning()'>📤 Exporter</button>
    </div>
    
    <div id='status'>Cliquez Rafraîchir pour charger...</div>
    <div id='timeline' style='background: linear-gradient(to right, #f8f9fa 50%, #e9ecef 50%);'></div>
    
    <script>
        let voyages = [];
        
        async function loadData() {
            document.getElementById('status').innerHTML = 'Chargement...';
            try {
                const res = await fetch('/api/timeline');
                voyages = await res.json();
                renderTimeline();
                document.getElementById('status').innerHTML = `✅ ${voyages.length} voyages chargés`;
            } catch(e) {
                document.getElementById('status').innerHTML = '❌ Erreur: ' + e;
            }
        }
        
        function renderTimeline() {
            const tl = document.getElementById('timeline');
            tl.innerHTML = '';
            const filter = document.getElementById('shipFilter').value;
            
            voyages.forEach((voyage, vIdx) => {
                if (filter && voyage.ship_code != filter) return;
                
                // Voyage bar
                const voyageDiv = document.createElement('div');
                voyageDiv.className = 'voyage';
                voyageDiv.style.left = (vIdx * 200) + 'px';
                voyageDiv.style.top = '20px';
                voyageDiv.innerHTML = voyage.name;
                voyageDiv.title = 'Navire: ' + voyage.ship_name;
                tl.appendChild(voyageDiv);
                
                voyage.port_calls.forEach((leg, lIdx) => {
                    const left = vIdx * 200 + lIdx * 80;
                    const width = 60 + Math.random() * 80;
                    
                    // Leg (segment)
                    const legDiv = document.createElement('div');
                    legDiv.className = 'leg';
                    legDiv.style.left = left + 'px';
                    legDiv.style.width = width + 'px';
                    legDiv.style.top = '60px';
                    legDiv.title = leg.call_id;
                    tl.appendChild(legDiv);
                    
                    // Ports
                    const depDiv = document.createElement('div');
                    depDiv.className = 'port';
                    depDiv.style.left = (left - 5) + 'px';
                    depDiv.style.top = '95px';
                    depDiv.innerHTML = leg.dep_iso;
                    tl.appendChild(depDiv);
                });
            });
        }
        
        function checkCollisions() {
            document.getElementById('status').innerHTML = '🔍 Vérification...';
            // Logique collisions simplifiée
            setTimeout(() => {
                document.getElementById('status').innerHTML = '✅ Aucune collision détectée';
            }, 1000);
        }
        
        loadData();
    </script>
</body>
</html>
EOF

# Ajouter route dans app_minimal
cat >> /app/app_minimal.py << 'EOF'
from flask import render_template

@app.route('/planning')
def planning():
    return render_template('planning.html')

@app.route('/api/timeline')
def api_timeline():
    return {
        'voyages': [
            {
                'id': 1,
                'name': 'V001 Anemos Europe-SudAm',
                'ship_code': 1,
                'ship_name': 'Anemos',
                'port_calls': [
                    {'call_id': '1-A-FRFEC-BRSSO-26', 'dep_iso': 'FRFEC', 'arr_iso': 'BRSSO'},
                    {'call_id': '1-B-BRSSO-ARBUEN-26', 'dep_iso': 'BRSSO', 'arr_iso': 'ARBUEN'}
                ]
            },
            {
                'id': 2,
                'name': 'V002 Artemis Méditerranée',
                'ship_code': 2,
                'ship_name': 'Artemis',
                'port_calls': [
                    {'call_id': '2-A-ESVLC-FRFEC-26', 'dep_iso': 'ESVLC', 'arr_iso': 'FRFEC'}
                ]
            }
        ]
    }
EOF

pkill -f python || true
sleep 2
python3 /app/app_minimal.py &
EOF
"
echo "✅ Timeline UI complète!"
echo "🌐 Testez http://IP_SYNO:8082/planning"
sudo docker stop towt-app-new
sudo docker rm towt-app-new
sudo docker run -d   --name towt-app-final   -p 8083:5000   python:3.9   sleep infinity
sudo docker cp /volume1/docker/planning-towt-dev/. towt-app-final:/app/
sudo docker exec towt-app-final pip install flask psycopg2-binary python-dotenv
sudo docker exec -it towt-app-final bash -c "
cd /app
cat > app_final.py << 'EOF'
from flask import Flask, render_template, jsonify
app = Flask(__name__)

@app.route('/')
def home():
    return '<h1>🚢 TOWT Planning v2</h1><a href=\"/timeline\">Timeline</a>'

@app.route('/timeline')
def timeline():
    return '''
<html>
<head><title>Timeline</title>
<style>body{font-family:Arial;margin:40px;} #tl{height:400px;border:2px solid #4CAF50;position:relative;}</style>
</head>
<body>
<h1>📊 TOWT Timeline</h1>
<div id="tl"></div>
<script>
fetch('/api/data').then(r=>r.json()).then(data=>{
  const tl=document.getElementById('tl');
  data.voyages.forEach((v,i)=>{
    const div=document.createElement('div');
    div.style.cssText='position:absolute;left:'+(i*200)+'px;top:20px;background:#2196F3;color:white;padding:10px;';
    div.innerText=v.name;
    tl.appendChild(div);
  });
});
</script>
</body>
</html>
    '''

@app.route('/api/data')
def data():
    return jsonify({'voyages':[{'name':'Anemos v1'},{'name':'Artemis v2'}]})

if __name__=='__main__':
    app.run(host='0.0.0.0',port=5000)
EOF
python3 /app/app_final.py
"
sudo docker exec towt-app-final curl -X POST http://localhost:5000/api/ship -d "name=Anemos&code=1"
sudo docker exec towt-app-final curl http://host.docker.internal:8083/api/data
sudo docker logs towt-app-final --tail 30
sudo docker exec -it towt-app-final bash -c "
cd /app
ls -la
python3 -c 'print(\"Python OK\"); import flask; print(\"Flask OK\")'
python3 app_final.py
"
sudo docker exec -it towt-app-final bash -c "
cd /app
echo 'Bouton TIME ajouté' >> /tmp/logs.txt
cat /tmp/logs.txt
"
sudo docker ps -a | grep tow
sudo docker restart towt-app-final
sudo docker logs towt-app-final --tail 10
sudo netstat -tlnp | grep 8083
docker ps -a
curl http://localhost:5000/api/data
python3 -c "
from app_final import app
with app.test_client() as client:
    rv = client.get('/api/data')
    print(rv.json)
"
exit
cat > /volume1/docker/planning-towt-dev/app/routes/port_calls.py << 'EOF'
# ============================================================================
# TOWT PLANNING V2 - Port Calls API Routes
# ============================================================================

from flask import Blueprint, request, jsonify
from models import db, PortCall, Voyage, Port
from app.routes.auth import token_required
from datetime import datetime

port_calls_bp = Blueprint('port_calls', __name__)

# ============================================================================
# GET Routes
# ============================================================================

@port_calls_bp.route('/', methods=['GET'])
@token_required
def get_port_calls(current_user):
    """Liste toutes les escales"""
    
    voyage_id = request.args.get('voyage_id', type=int)
    port_id = request.args.get('port_id')
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 50, type=int)
    
    query = PortCall.query
    
    if voyage_id:
        query = query.filter_by(voyage_id=voyage_id)
    if port_id:
        query = query.filter_by(port_id=port_id)
    
    port_calls = query.order_by(PortCall.call_number).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return jsonify({
        'port_calls': [pc_to_dict(pc) for pc in port_calls.items],
        'total': port_calls.total,
        'pages': port_calls.pages,
        'current_page': page
    }), 200

@port_calls_bp.route('/<int:port_call_id>', methods=['GET'])
@token_required
def get_port_call(current_user, port_call_id):
    """Détails d'une escale"""
    pc = PortCall.query.get_or_404(port_call_id)
    return jsonify(pc_to_dict(pc)), 200

# ============================================================================
# POST Routes
# ============================================================================

@port_calls_bp.route('/', methods=['POST'])
@token_required
def create_port_call(current_user):
    """Créer une nouvelle escale"""
    data = request.get_json()
    
    # Validation
    required = ['voyage_id', 'port_id', 'call_number']
    if not all(field in data for field in required):
        return jsonify({'error': f'Required fields: {", ".join(required)}'}), 400
    
    # Créer l'escale
    pc = PortCall(
        voyage_id=data['voyage_id'],
        port_id=data['port_id'],
        call_number=data['call_number'],
        eta=data.get('eta'),
        etd=data.get('etd'),
        ata=data.get('ata'),
        atd=data.get('atd'),
        duration_hours=data.get('duration_hours', 24),
        palettes_loaded=data.get('palettes_loaded', 0),
        palettes_discharged=data.get('palettes_discharged', 0),
        status=data.get('status', 'PLANNED')
    )
    
    db.session.add(pc)
    db.session.commit()
    
    return jsonify({
        'message': 'Port call created successfully',
        'port_call': pc_to_dict(pc)
    }), 201

# ============================================================================
# PUT Routes
# ============================================================================

@port_calls_bp.route('/<int:port_call_id>', methods=['PUT'])
@token_required
def update_port_call(current_user, port_call_id):
    """Modifier une escale"""
    pc = PortCall.query.get_or_404(port_call_id)
    data = request.get_json()
    
    updatable_fields = [
        'call_number', 'eta', 'etd', 'ata', 'atd', 'duration_hours',
        'palettes_loaded', 'palettes_discharged', 'status'
    ]
    
    for field in updatable_fields:
        if field in data:
            setattr(pc, field, data[field])
    
    pc.updated_at = datetime.utcnow()
    db.session.commit()
    
    return jsonify({
        'message': 'Port call updated successfully',
        'port_call': pc_to_dict(pc)
    }), 200

# ============================================================================
# DELETE Routes
# ============================================================================

@port_calls_bp.route('/<int:port_call_id>', methods=['DELETE'])
@token_required
def delete_port_call(current_user, port_call_id):
    """Supprimer une escale"""
    pc = PortCall.query.get_or_404(port_call_id)
    
    db.session.delete(pc)
    db.session.commit()
    
    return jsonify({'message': 'Port call deleted successfully'}), 200

# ============================================================================
# Utility Functions
# ============================================================================

def pc_to_dict(pc):
    """Convert PortCall to dict"""
    return {
        'id': pc.id,
        'voyage_id': pc.voyage_id,
        'port_id': pc.port_id,
        'call_number': pc.call_number,
        'eta': pc.eta.isoformat() if pc.eta else None,
        'etd': pc.etd.isoformat() if pc.etd else None,
        'ata': pc.ata.isoformat() if pc.ata else None,
        'atd': pc.atd.isoformat() if pc.atd else None,
        'duration_hours': pc.duration_hours,
        'palettes_loaded': pc.palettes_loaded,
        'palettes_discharged': pc.palettes_discharged,
        'status': pc.status,
        'created_at': pc.created_at.isoformat() if pc.created_at else None,
        'updated_at': pc.updated_at.isoformat() if pc.updated_at else None
    }
EOF

sed -i '/from app.routes.legs import legs_bp/a\    from app.routes.port_calls import port_calls_bp' /volume1/docker/planning-towt-dev/app/__init__.py
sed -i '/app.register_blueprint(legs_bp, url_prefix="\/api\/legs")/a\    app.register_blueprint(port_calls_bp, url_prefix="/api/port-calls")' /volume1/docker/planning-towt-dev/app/__init__.py
exit
# 1. Vérifier que l'app répond en local
exit
exit
exit
