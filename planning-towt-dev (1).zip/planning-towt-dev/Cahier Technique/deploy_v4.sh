#!/bin/bash
set -e
CONTAINER="towt-app-v2"
ZIP_SOURCE="/volume1/homes/admin.5g/app_modified.zip"

echo "=== Deploy v4: Passengers + Cargo fixes ==="

docker cp "$ZIP_SOURCE" $CONTAINER:/tmp/app_update.zip
docker exec $CONTAINER python3 -c "
import zipfile
with zipfile.ZipFile('/tmp/app_update.zip','r') as z:
    z.extractall('/tmp/app_extract')
"

FILES=(
    routers/passenger_router.py
    routers/kpi_router.py
    routers/claim_router.py
    templates/passengers/detail.html
    templates/passengers/external.html
    templates/cargo/detail.html
    templates/cargo/client_form.html
    templates/kpi/index.html
    templates/admin/settings.html
    templates/claims/detail.html
    i18n/__init__.py
)

for f in "${FILES[@]}"; do
    docker exec $CONTAINER cp /tmp/app_extract/$f /app/app/$f 2>/dev/null && echo "  ✓ $f" || echo "  ⚠ $f (skipped)"
done

docker exec $CONTAINER pkill -f uvicorn || true
sleep 2
docker exec -d $CONTAINER uvicorn app.main:app --host 0.0.0.0 --port 8000
sleep 3

echo ""
echo "=== Deployment complete ==="
echo ""
echo "Passagers backoffice:"
echo "  ✓ Modifier/supprimer paiements (hors CB)"
echo "  ✓ Upload documents depuis backoffice"
echo "  ✓ Téléchargement documents"
echo "  ✓ Lien passager avec port :8081"
echo ""
echo "Cargo:"
echo "  ✓ Lien client avec port :8081"
echo "  ✓ Traduction labels batch (type palette, nature, bio, etc.)"
echo "  ✓ Traduction labels voyage info"
echo ""
echo "Claims (rappel v3):"
echo "  ✓ Formule: Provision - Franchise - Prise en charge = Reste à charge"
echo "  ✓ KPI sinistralité"
echo "  ✓ Doublon bouton assurance supprimé"
