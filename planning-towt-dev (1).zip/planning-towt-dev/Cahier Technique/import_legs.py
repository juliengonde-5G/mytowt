"""
Import historical legs from Vessel_Historic_Timeline.xlsx into the TOWT database.
Runs INSIDE the Docker container.

- Creates missing ports from the PORTS sheet
- Imports legs from ANEMOS/ARTEMIS LIST VIEW sheets
- Handles different column names (ATD/ATA vs DEPARTURE/ARRIVAL)
- Skips legs without TRIP CODE
- Sets year from ETD date
- Computes sequence from leg_code letter
"""
import os
import sys
import re
import time
from datetime import datetime, timezone

sys.path.insert(0, '/app')
import psycopg2
import pandas as pd

# --- Config ---
XLSX_PATH = "/tmp/Vessel_Historic_Timeline.xlsx"
DB_URL = os.environ.get("DATABASE_URL", "")

m = re.match(r'postgresql(?:\+\w+)?://([^:]+):([^@]+)@([^:]+):(\d+)/(.+)', DB_URL)
if not m:
    print(f"ERROR: Cannot parse DATABASE_URL: {DB_URL}")
    sys.exit(1)

DB_PARAMS = {
    "user": m.group(1), "password": m.group(2),
    "host": m.group(3), "port": int(m.group(4)), "dbname": m.group(5),
}

# Vessel name → sheet name mapping
VESSEL_SHEETS = {
    "ANEMOS LIST VIEW": "anemos",
    "ARTEMIS LIST VIEW": "artemis",
}


def parse_date(val):
    """Parse various date formats from the Excel file."""
    if pd.isna(val) or val is None:
        return None
    if isinstance(val, datetime):
        if val.tzinfo is None:
            return val.replace(tzinfo=timezone.utc)
        return val
    s = str(val).strip()
    if not s:
        return None
    # Try dd/mm/yyyy format
    for fmt in ["%d/%m/%Y", "%Y-%m-%d", "%Y-%m-%d %H:%M:%S"]:
        try:
            dt = datetime.strptime(s, fmt)
            return dt.replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    return None


def extract_sequence(trip_code):
    """Extract sequence number from trip code letter. e.g. 1LY1A4 → A=1, 1YMB4 → B=2."""
    if not trip_code or len(trip_code) < 2:
        return 1
    # The letter before the last digit is the sequence letter
    # Format: SHIPCODE + LETTER + DEP_COUNTRY + ARR_COUNTRY + YEAR_LAST_DIGIT
    # Find the letter in position after vessel code digit
    # E.g.: 1ZL0A4 → vessel=1, then parse... 
    # Actually the sequence letter is embedded. Let's extract from the known format:
    # code[1] could be part of port code. Let's look for the uppercase letter pattern.
    # Simpler: count the leg order per vessel, we'll use the row index
    return None  # We'll compute from row order


def main():
    start = time.time()
    
    conn = psycopg2.connect(**DB_PARAMS)
    conn.autocommit = False
    cur = conn.cursor()

    # Read Excel
    xl = pd.read_excel(XLSX_PATH, sheet_name=None)
    
    # ─── 1. Import Ports ───────────────────────────────────
    print("=== Importing Ports ===")
    if "PORTS" in xl:
        ports_df = xl["PORTS"]
        # Get existing ports
        cur.execute("SELECT locode FROM ports")
        existing_ports = {r[0] for r in cur.fetchall()}
        
        added_ports = 0
        for _, row in ports_df.iterrows():
            locode = str(row.get("PO ID", "")).strip().upper()
            name = str(row.get("PO Nom", "")).strip()
            country = str(row.get("PO Country", "")).strip()
            
            if not locode or len(locode) < 3:
                continue
            
            # Country code = first 2 chars of locode
            country_code = locode[:2]
            zone = str(row.get("PO Zone", "")).strip() if pd.notna(row.get("PO Zone")) else None
            
            if locode not in existing_ports:
                cur.execute("""
                    INSERT INTO ports (locode, name, country_code, zone_code)
                    VALUES (%s, %s, %s, %s)
                    ON CONFLICT (locode) DO NOTHING
                """, (locode, name, country_code, zone))
                if cur.rowcount > 0:
                    added_ports += 1
                    existing_ports.add(locode)
        
        conn.commit()
        print(f"  Ports: {added_ports} added, {len(existing_ports)} total")
    
    # ─── 2. Load vessels ───────────────────────────────────
    cur.execute("SELECT id, code, LOWER(name) FROM vessels")
    vessels = {name: {"id": vid, "code": vcode} for vid, vcode, name in cur.fetchall()}
    print(f"  Vessels in DB: {list(vessels.keys())}")
    
    # ─── 3. Load existing legs to avoid duplicates ─────────
    cur.execute("SELECT leg_code FROM legs")
    existing_legs = {r[0] for r in cur.fetchall()}
    print(f"  Existing legs: {len(existing_legs)}")
    
    # ─── 4. Import Legs per vessel sheet ───────────────────
    total_imported = 0
    total_skipped = 0
    total_errors = 0
    
    for sheet_name, vessel_key in VESSEL_SHEETS.items():
        if sheet_name not in xl:
            print(f"\n  WARNING: Sheet '{sheet_name}' not found, skipping")
            continue
        
        df = xl[sheet_name]
        print(f"\n=== {sheet_name} ({len(df)} rows) ===")
        
        # Find vessel
        vessel_info = None
        for db_name, info in vessels.items():
            if vessel_key in db_name:
                vessel_info = info
                break
        
        if not vessel_info:
            print(f"  ERROR: Vessel '{vessel_key}' not found in DB")
            total_errors += len(df)
            continue
        
        vessel_id = vessel_info["id"]
        vessel_code = vessel_info["code"]
        
        # Detect column names (Anemos uses ATD/ATA, Artemis uses DEPARTURE/ARRIVAL)
        cols = list(df.columns)
        atd_col = "ATD" if "ATD" in cols else "DEPARTURE"
        ata_col = "ATA" if "ATA" in cols else "ARRIVAL"
        
        sequence = 0
        for idx, row in df.iterrows():
            trip_code = str(row.get("TRIP CODE", "")).strip()
            if not trip_code or trip_code == "nan":
                total_skipped += 1
                continue
            
            # Skip if already exists
            if trip_code in existing_legs:
                print(f"  SKIP {trip_code} (already exists)")
                total_skipped += 1
                continue
            
            pol = str(row.get("POL ID", "")).strip().upper()
            pod = str(row.get("POD ID", "")).strip().upper()
            
            if not pol or not pod or pol == "NAN" or pod == "NAN":
                total_skipped += 1
                continue
            
            # Ensure ports exist (create minimal entry if missing)
            for port_code, port_name_col in [(pol, "POL NAME"), (pod, "POD NAME")]:
                cur.execute("SELECT locode FROM ports WHERE locode = %s", (port_code,))
                if not cur.fetchone():
                    port_name = str(row.get(port_name_col, port_code)).strip()
                    country_code = port_code[:2]
                    cur.execute("""
                        INSERT INTO ports (locode, name, country_code)
                        VALUES (%s, %s, %s)
                        ON CONFLICT (locode) DO NOTHING
                    """, (port_code, port_name, country_code))
                    print(f"  Created port: {port_code} ({port_name})")
            
            etd = parse_date(row.get("ETD"))
            eta = parse_date(row.get("ETA"))
            atd = parse_date(row.get(atd_col))
            ata = parse_date(row.get(ata_col))
            
            # Determine year from ETD or trip code
            year = None
            if etd:
                year = etd.year
            elif trip_code:
                # Last char is year digit: 4=2024, 5=2025, 6=2026
                last = trip_code[-1]
                if last.isdigit():
                    year = 2020 + int(last)
            if not year:
                year = 2024
            
            # Sequence: increment per vessel per year
            sequence += 1
            
            # Status
            if ata:
                status = "completed"
            elif atd:
                status = "in_progress"
            else:
                status = "planned"
            
            try:
                cur.execute("""
                    INSERT INTO legs (leg_code, vessel_id, year, sequence, 
                                     departure_port_locode, arrival_port_locode,
                                     etd, eta, atd, ata, status)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """, (trip_code, vessel_id, year, sequence, pol, pod,
                      etd, eta, atd, ata, status))
                total_imported += 1
                existing_legs.add(trip_code)
                print(f"  + {trip_code}: {pol} → {pod} ({year}) [{status}]")
            except Exception as e:
                print(f"  ERROR {trip_code}: {e}")
                conn.rollback()
                total_errors += 1
                continue
        
        conn.commit()
    
    # ─── 5. Re-match GPS positions to new legs ────────────
    print("\n=== Re-matching GPS positions to legs ===")
    cur.execute("SELECT COUNT(*) FROM vessel_positions WHERE leg_id IS NULL")
    unmatched = cur.fetchone()[0]
    print(f"  Unmatched positions: {unmatched}")
    
    if unmatched > 0:
        # Load all legs for matching
        cur.execute("""
            SELECT id, vessel_id, etd, eta, atd, ata 
            FROM legs ORDER BY vessel_id, sequence
        """)
        all_legs = {}
        for lid, vid, etd, eta, atd, ata in cur.fetchall():
            all_legs.setdefault(vid, []).append({
                "id": lid, "etd": etd, "eta": eta, "atd": atd, "ata": ata
            })
        
        # Get unmatched positions
        cur.execute("""
            SELECT id, vessel_id, recorded_at FROM vessel_positions 
            WHERE leg_id IS NULL
            ORDER BY vessel_id, recorded_at
        """)
        positions = cur.fetchall()
        
        matched = 0
        batch = []
        for pos_id, vessel_id, recorded_at in positions:
            legs = all_legs.get(vessel_id, [])
            leg_id = None
            
            if recorded_at.tzinfo is None:
                dt = recorded_at.replace(tzinfo=timezone.utc)
            else:
                dt = recorded_at
            
            # Priority 1: ATD <= dt <= ATA
            for leg in legs:
                if leg["atd"] and leg["atd"] <= dt:
                    if leg["ata"] is None or leg["ata"] >= dt:
                        leg_id = leg["id"]
                        break
            
            # Priority 2: ETD <= dt <= ETA
            if not leg_id:
                for leg in legs:
                    if leg["etd"] and leg["etd"] <= dt:
                        if leg["eta"] is None or leg["eta"] >= dt:
                            leg_id = leg["id"]
                            break
            
            # Priority 3: nearest leg before
            if not leg_id:
                best, best_diff = None, None
                for leg in legs:
                    end = leg["ata"] or leg["eta"]
                    if end and end <= dt:
                        diff = (dt - end).total_seconds()
                        if best_diff is None or diff < best_diff:
                            best_diff = diff
                            best = leg["id"]
                leg_id = best
            
            if leg_id:
                batch.append((leg_id, pos_id))
                matched += 1
            
            if len(batch) >= 500:
                cur.executemany("UPDATE vessel_positions SET leg_id = %s WHERE id = %s", batch)
                conn.commit()
                batch = []
        
        if batch:
            cur.executemany("UPDATE vessel_positions SET leg_id = %s WHERE id = %s", batch)
            conn.commit()
        
        print(f"  Matched {matched}/{len(positions)} positions to legs")
    
    elapsed = time.time() - start
    cur.close()
    conn.close()
    
    print(f"\n{'='*50}")
    print(f"IMPORT COMPLETE in {elapsed:.1f}s")
    print(f"{'='*50}")
    print(f"Legs: {total_imported} imported | {total_skipped} skipped | {total_errors} errors")
    print(f"{'='*50}")


if __name__ == "__main__":
    main()
