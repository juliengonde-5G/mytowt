-- ═══════════════════════════════════════════════════════════
-- TOWT Commercial Module — Database Migration
-- Run this ONLY if the tables don't exist yet
-- ═══════════════════════════════════════════════════════════

-- 1. Clients
CREATE TABLE IF NOT EXISTS clients (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    client_type VARCHAR(30) NOT NULL,  -- 'freight_forwarder' | 'shipper'
    contact_name VARCHAR(200),
    contact_email VARCHAR(200),
    contact_phone VARCHAR(50),
    address TEXT,
    country VARCHAR(100),
    notes TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Rate Grids
CREATE TABLE IF NOT EXISTS rate_grids (
    id SERIAL PRIMARY KEY,
    reference VARCHAR(50) UNIQUE NOT NULL,
    client_id INTEGER NOT NULL REFERENCES clients(id),
    vessel_id INTEGER REFERENCES vessels(id),
    valid_from DATE NOT NULL,
    valid_to DATE NOT NULL,
    adjustment_index FLOAT DEFAULT 1.0,
    bl_fee FLOAT DEFAULT 0,
    booking_fee FLOAT DEFAULT 0,
    volume_commitment INTEGER,
    status VARCHAR(20) DEFAULT 'draft',
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    created_by VARCHAR(100)
);
CREATE INDEX IF NOT EXISTS idx_rg_client ON rate_grids(client_id);
CREATE INDEX IF NOT EXISTS idx_rg_status ON rate_grids(status);

-- 3. Rate Grid Lines
CREATE TABLE IF NOT EXISTS rate_grid_lines (
    id SERIAL PRIMARY KEY,
    rate_grid_id INTEGER NOT NULL REFERENCES rate_grids(id) ON DELETE CASCADE,
    pol_locode VARCHAR(5) NOT NULL REFERENCES ports(locode),
    pod_locode VARCHAR(5) NOT NULL REFERENCES ports(locode),
    distance_nm FLOAT,
    nav_days FLOAT,
    opex_daily FLOAT,
    base_rate FLOAT,
    rate_lt10 FLOAT,
    rate_10to50 FLOAT,
    rate_51to100 FLOAT,
    rate_gt100 FLOAT,
    is_manual BOOLEAN DEFAULT FALSE
);
CREATE INDEX IF NOT EXISTS idx_rgl_grid ON rate_grid_lines(rate_grid_id);

-- 4. Rate Offers
CREATE TABLE IF NOT EXISTS rate_offers (
    id SERIAL PRIMARY KEY,
    reference VARCHAR(50) UNIQUE NOT NULL,
    client_id INTEGER NOT NULL REFERENCES clients(id),
    rate_grid_id INTEGER NOT NULL REFERENCES rate_grids(id),
    validity_date DATE NOT NULL,
    status VARCHAR(20) DEFAULT 'draft',
    document_filename VARCHAR(255),
    document_path VARCHAR(500),
    notes TEXT,
    sent_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    created_by VARCHAR(100)
);
CREATE INDEX IF NOT EXISTS idx_ro_client ON rate_offers(client_id);
CREATE INDEX IF NOT EXISTS idx_ro_grid ON rate_offers(rate_grid_id);

-- 5. Add rate grid linkage to orders (if not exists)
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='orders' AND column_name='rate_grid_id') THEN
        ALTER TABLE orders ADD COLUMN rate_grid_id INTEGER REFERENCES rate_grids(id);
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='orders' AND column_name='rate_grid_line_id') THEN
        ALTER TABLE orders ADD COLUMN rate_grid_line_id INTEGER REFERENCES rate_grid_lines(id);
    END IF;
END $$;

-- 6. Company parameters for BL fee and Booking fee (insert if not exists)
INSERT INTO opex_parameters (parameter_name, parameter_value, unit, category, description)
VALUES ('bl_fee', 75.0, 'EUR', 'commercial', 'BL fee per order')
ON CONFLICT (parameter_name) DO NOTHING;

INSERT INTO opex_parameters (parameter_name, parameter_value, unit, category, description)
VALUES ('booking_fee', 50.0, 'EUR', 'commercial', 'Booking fee per order')
ON CONFLICT (parameter_name) DO NOTHING;
