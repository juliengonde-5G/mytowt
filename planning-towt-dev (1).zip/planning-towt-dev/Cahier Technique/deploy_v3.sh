#!/bin/bash
set -e
CONTAINER="my_towt-web-1"

echo "=== Deploy v3: Corrections + KPI Sinistralité ==="

# Copy and extract
docker cp /home/app_modified.zip $CONTAINER:/tmp/app_update.zip
docker exec $CONTAINER python3 -c "
import zipfile, os
with zipfile.ZipFile('/tmp/app_update.zip','r') as z:
    z.extractall('/tmp/app_extract')
"

# Copy modified files
for f in routers/claim_router.py routers/kpi_router.py templates/claims/detail.html templates/kpi/index.html templates/admin/settings.html; do
    docker exec $CONTAINER cp /tmp/app_extract/$f /app/app/$f
    echo "  ✓ $f"
done

# Restart
docker exec $CONTAINER pkill -f uvicorn || true
sleep 2
docker exec -d $CONTAINER uvicorn app.main:app --host 0.0.0.0 --port 8000
sleep 3

echo "=== Deployment complete ==="
echo "Corrections:"
echo "  ✓ Doublon bouton assurance supprimé"
echo "  ✓ Formule: Provision - Franchise - Prise en charge = Reste à charge"
echo "  ✓ Labels renommés (Prise en charge / Reste à charge)"
echo "  ✓ KPI sinistralité ajouté (cards + barres + statuts)"
