#!/bin/bash
set -e
CONTAINER="towt-app-v2"
ZIP_SOURCE="/volume1/homes/admin.5g/app_modified.zip"

echo "=== Deploy v7: Messagerie backoffice ==="

sudo docker cp "$ZIP_SOURCE" $CONTAINER:/tmp/app_update.zip

sudo docker exec $CONTAINER python3 -c "
import zipfile, shutil, os
if os.path.exists('/tmp/app_extract'):
    shutil.rmtree('/tmp/app_extract')
with zipfile.ZipFile('/tmp/app_update.zip','r') as z:
    z.extractall('/tmp/app_extract')
print('Extracted OK')
"

FILES=(
    routers/cargo_router.py
    templates/cargo/detail.html
    templates/passengers/detail.html
)

for f in "${FILES[@]}"; do
    sudo docker exec $CONTAINER mkdir -p "/app/app/$(dirname $f)" 2>/dev/null
    sudo docker exec $CONTAINER cp "/tmp/app_extract/$f" "/app/app/$f" 2>/dev/null && echo "  ✓ $f" || echo "  ⚠ $f (skipped)"
done

sudo docker exec $CONTAINER bash -c "kill \$(ps aux | grep uvicorn | grep -v grep | awk '{print \$2}') 2>/dev/null" || true
sleep 2
sudo docker exec -d $CONTAINER uvicorn app.main:app --host 0.0.0.0 --port 8000
sleep 3

echo ""
echo "=== Deployment complete ==="
echo ""
echo "Messagerie backoffice:"
echo "  ✓ Passagers: section messagerie dans /passengers/{id}"
echo "  ✓ Cargo: section messagerie dans /cargo/{id}"
echo "  ✓ Envoyer des messages (company → client)"
echo "  ✓ Badge messages non lus"
echo "  ✓ Marquer comme lus"
echo "  ✓ Thread avec bulles (client=gauche, TOWT=droite)"
