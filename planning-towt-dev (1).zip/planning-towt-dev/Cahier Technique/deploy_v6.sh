#!/bin/bash
set -e
CONTAINER="towt-app-v2"
ZIP_SOURCE="/volume1/homes/admin.5g/app_modified.zip"

echo "=== Deploy v6: Portail cargo complet ==="

sudo docker cp "$ZIP_SOURCE" $CONTAINER:/tmp/app_update.zip

sudo docker exec $CONTAINER python3 -c "
import zipfile, shutil, os
if os.path.exists('/tmp/app_extract'):
    shutil.rmtree('/tmp/app_extract')
with zipfile.ZipFile('/tmp/app_update.zip','r') as z:
    z.extractall('/tmp/app_extract')
print('Extracted OK')
# Verify files exist
for f in ['templates/cargo/portal_base.html','templates/cargo/portal_packing.html']:
    path = '/tmp/app_extract/' + f
    print(f'  {f}: {os.path.exists(path)}')
"

FILES=(
    routers/cargo_router.py
    i18n/__init__.py
    templates/cargo/portal_base.html
    templates/cargo/portal_packing.html
    templates/cargo/portal_vessel.html
    templates/cargo/portal_voyage.html
    templates/cargo/portal_docs.html
    templates/cargo/portal_messages.html
)

for f in "${FILES[@]}"; do
    sudo docker exec $CONTAINER mkdir -p "/app/app/$(dirname $f)" 2>/dev/null
    sudo docker exec $CONTAINER cp "/tmp/app_extract/$f" "/app/app/$f" 2>/dev/null && echo "  ✓ $f" || echo "  ⚠ $f (skipped)"
done

# Restart uvicorn (pkill not available, use kill)
sudo docker exec $CONTAINER bash -c "kill \$(ps aux | grep uvicorn | grep -v grep | awk '{print \$2}') 2>/dev/null" || true
sleep 2
sudo docker exec -d $CONTAINER uvicorn app.main:app --host 0.0.0.0 --port 8000
sleep 3

echo ""
echo "=== Deployment complete ==="
echo ""
echo "Portail cargo (5 pages avec sidebar):"
echo "  ✓ /p/{token}           → Packing List"
echo "  ✓ /p/{token}/vessel    → Le Navire"
echo "  ✓ /p/{token}/voyage    → Le Voyage + itinéraire + équipage"
echo "  ✓ /p/{token}/documents → Documentation + CGT"
echo "  ✓ /p/{token}/messages  → Messagerie client"
echo ""
echo "  ✓ Traduction complète FR/EN/ES/PT-BR/VI"
echo "  ✓ Sidebar responsive mobile"
echo "  ✓ Badge messages non lus"
