#!/bin/bash
# Deploy Commercial Module Update - TOWT v8
# Adds: grid_detail.html, offer_form.html, offers.html + main.py (pricing_router)
set -e

CONTAINER="towt-app-v2"
UPLOAD_DIR="/volume1/homes/admin.5g"
ZIP_FILE="commercial_module.zip"

echo "=== TOWT Commercial Module Deployment ==="

# 1. Copy ZIP into container
echo "[1/4] Copying ZIP to container..."
docker cp "${UPLOAD_DIR}/${ZIP_FILE}" "${CONTAINER}:/tmp/${ZIP_FILE}"

# 2. Extract files
echo "[2/4] Extracting files..."
docker exec "${CONTAINER}" unzip -o "/tmp/${ZIP_FILE}" -d /app

# 3. Fix permissions
echo "[3/4] Fixing permissions..."
docker exec "${CONTAINER}" chmod -R a+r /app/app/templates/commercial/
docker exec "${CONTAINER}" chmod -R a+r /app/app/main.py

# 4. Restart
echo "[4/4] Restarting container..."
docker restart "${CONTAINER}"

echo ""
echo "=== Deployment complete ==="
echo "Files deployed:"
echo "  - app/main.py (added pricing_router)"
echo "  - app/templates/commercial/grid_detail.html (NEW)"
echo "  - app/templates/commercial/offer_form.html (NEW)"
echo "  - app/templates/commercial/offers.html (NEW)"
echo ""
echo "Migration SQL (run if tables don't exist yet):"
echo "  -- clients, rate_grids, rate_grid_lines, rate_offers tables"
echo "  -- See migration below"
